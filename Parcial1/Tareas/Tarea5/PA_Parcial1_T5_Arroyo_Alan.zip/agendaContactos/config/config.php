<?php
    $server = "localhost";
    $user = "root";
    $password = "";
    $db = "agenda_contactos";
?>
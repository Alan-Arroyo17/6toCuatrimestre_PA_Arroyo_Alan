<?php
    require_once ("config/connection.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/style.css">
    <title>Agenda De Contactos</title>
</head>
<body>
    <?php if(isset($_GET['success'])): ?>
        <div class="alert alert-success">
            <?= htmlspecialchars($_GET['success']) ?>
        </div>
    <?php endif; ?>

    <?php if(isset($_GET['error'])): ?>
        <div class="alert alert-error">
            <?= htmlspecialchars($_GET['error']) ?>
        </div>
    <?php endif; ?>
    <h1>Contactos</h1>
    <div class="form-container">
        <table>
            <caption>
                <button><a href="crud-php/create.php">Nuevo Contacto</a></button>
            </caption>
            <th>
                <tr>
                    <th>Nombre</th>
                    <th >Telefono</th>
                    <th>Correo</th>
                    <th>Acciones</th>
                </tr>
            </th>
            <?php
                $stmt = $conn->prepare("SELECT id, nombre, apellido, telefono, email FROM contactos");
                $stmt->execute();
                $contactos = $stmt->get_result();
                while($row = $contactos->fetch_assoc()){
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row["nombre"] . " " . $row["apellido"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["telefono"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["email"]) . "</td>";
                    echo "<td>";
                    echo "<a href='crud-php/edit.php?id=" . urlencode($row["id"]) . "'>Editar</a> ";
                    echo "<a href='crud-php/delete.php?id=" . urlencode($row["id"]) . "'>Eliminar</a>";
                    echo "</td>";
                    echo "</tr>";
                }
                $stmt->close();
                $conn->close();
            ?>
        </table>
    </div>
</body>
</html>
<?php
    require_once("../config/connection.php");

    if($_SERVER["REQUEST_METHOD"] != "POST"){
        header("Location: ../index.php");
        exit();
    }


    $nombre = trim($_POST["nombre"]);
    $apellido = trim($_POST["apellido"]);
    $telefono = trim($_POST["telefono"]);
    $correo = trim($_POST["correo"]);

    $stmt = $conn->prepare("INSERT INTO contactos(nombre, apellido, telefono, email) VALUES (?, ?, ?, ?)"); 
    $stmt->bind_param("ssss",$nombre, $apellido, $telefono, $correo);
    if ($stmt->execute()) {
        header("Location: ../index.php?success=" . urlencode("Contacto creado exitosamente"));
    } else {
        header("Location: crud-php/create.php?error=" . urlencode("Error al crear el contacto: " . $stmt->error));
    }

?>
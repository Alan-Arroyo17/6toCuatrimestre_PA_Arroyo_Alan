<?php
    require_once("../config/connection.php");

    $id = intval($_GET["id"] ?? 0);

    if ($id <= 0) {
        header("Location: ../index.php?error=" . urlencode("ID inválido"));
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM contactos WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: ../index.php?success=" . urlencode("Contacto eliminado exitosamente"));
        exit;
    } else {
        header("Location: ../index.php?error=" . urlencode("Error al eliminar el contacto: " . $stmt->error));
        exit;
    }
    $stmt->close();
    $conn->close();
?>
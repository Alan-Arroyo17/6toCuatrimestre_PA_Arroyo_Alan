<?php
    require_once ("../config/connection.php");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Contacto</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="form-container">
        <form action="save.php" method="POST">
            <label for="Nombre">Nombre:</label>
            <input type="text" name="nombre" required>

            <label for="Nombre">Apellido:</label>
            <input type="text" name="apellido" required>

            <label for="Nombre">Teléfono:</label>
            <input type="text" name="telefono" required>

            <label for="Nombre">Correo:</label>
            <input type="email" name="correo" required>

            <div class="form-buttons">
                <button type="submit">Registrar</button>
                <a href="../index.php">Volver</a>
            </div>
        </form>
    </div>
</body>
</html>
    <?php
        require_once ("../config/connection.php");

        $id = intval($_GET["id"] ?? 0);
        if($id>0){
            $stmt = $conn->prepare("SELECT nombre, apellido, telefono, email FROM contactos WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $contacto = $resultado->fetch_assoc();
            $stmt->close();
            $conn->close();
        }else {
            header("Location: ../index.php?error=" . urlencode("ID inválido"));
            exit;
        }
    ?>

    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Editar Contacto</title>
        <link rel="stylesheet" href="../assets/style.css">
    </head>
    <body>
        <div class="form-container">
            <form action="update.php" method="POST">
                <input type="hidden" name="id" value="<?= $contacto["id"] ?? $id ?>">

                <label for="nombre">Nombre:</label>
                <input type="text" name="nombre" value="<?= htmlspecialchars($contacto["nombre"] ?? "") ?>">

                <label for="apellido">Apellido:</label>
                <input type="text" name="apellido" value="<?= htmlspecialchars($contacto["apellido"] ?? "") ?>">

                <label for="telefono">Teléfono:</label>
                <input type="text" name="telefono" value="<?= htmlspecialchars($contacto["telefono"] ?? "") ?>">

                <label for="correo">Correo:</label>
                <input type="email" name="correo" value="<?= htmlspecialchars($contacto["email"] ?? "") ?>">

                <div class="form-buttons">
                <button type="submit">Editar</button>
                <a href="../index.php">Volver</a>
            </div>
            </form>
        </div>
    </body>
    </html>
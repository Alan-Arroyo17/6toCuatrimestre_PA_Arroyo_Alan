<?php
    require_once ("../config/connection.php");

    $id = intval($_POST["id"] ?? 0);
    $nombre = trim($_POST["nombre"] ?? "");
    $apellido = trim($_POST["apellido"]) ?? "";
    $telefono = trim($_POST["telefono"] ?? "");
    $correo = trim($_POST["correo"] ?? "");

    if ($id <= 0 || $nombre === "" || $apellido === "") {
        header("Location: ../index.php?error=" . urlencode("Datos inválidos"));
        exit;
    }

    $stmt = $conn->prepare("UPDATE contactos SET nombre=?, apellido=?, telefono=?, email=? WHERE id=?");
    $stmt->bind_param("ssssi", $nombre, $apellido, $telefono, $correo, $id);

    if ($stmt->execute()) {
        header("Location: ../index.php?success=" . urlencode("Contacto actualizado exitosamente"));
        exit;
    } else {
        header("Location: ../index.php?error=" . urlencode("Error al actualizar el contacto: " . $stmt->error));
        exit;
    }
    $stmt->close();
    $conn->close();
?>
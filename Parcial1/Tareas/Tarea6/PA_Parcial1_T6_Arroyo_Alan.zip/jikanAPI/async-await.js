const BASE_URL = "https://api.jikan.moe/v4/";    

//Animes de temporada
async function obtenerAnimesDeTemporada(){
    try {
        const response = await fetch(`${BASE_URL}seasons/now?limit=12`);

        if (response.ok) {
            const data = await response.json();
            const getResultDiv = document.getElementById("get-result");
            getResultDiv.innerHTML = "";
            data.data.forEach(anime => {
                getResultDiv.innerHTML += `
                    <div class="card">
                        <img src="${anime.images.jpg.image_url}">
                        <h3>${anime.title}</h3>
                        <p><strong>Estado:</strong>
                        ${anime.status}</p>
                        <p><strong>Puntuación:</strong>
                        ${anime.score ?? "Sin calificación"}</p>

                        <button onclick="obtenerPersonajes(${anime.mal_id})">
                            Ver personajes
                        </button>

                        <div id="personajes-${anime.mal_id}"></div>
                    </div>
                `;
            });
        } else {
            throw new Error(`Error en la respuesta: ${response.status}`);
        }
    } catch (error) {
        console.error("Error al obtener la temporada:", error);
    } finally {
        console.log("Ejecución de obtenerTemporada finalizada");
    }
}

async function obtenerPersonajes(idAnime) {
    try {
        const response = await fetch(`${BASE_URL}anime/${idAnime}/characters`);

        if (response.ok) {
            const data = await response.json();
            const contenedor = document.getElementById(`personajes-${idAnime}`);
            contenedor.innerHTML = "";

            if (data.data.length === 0) {
                contenedor.innerHTML = "<p>No hay personajes disponibles.</p>";
                return;
            }

            let personajes = "<h4>Personajes:</h4>";

            data.data.slice(0, 5).forEach(personaje => {
                personajes += `
                    <p>${personaje.character.name}</p>
                `;
            });

            contenedor.innerHTML = personajes;
        } else {
            throw new Error(
                `Error en la respuesta: ${response.status}`
            );
        }
    } catch (error) {
        console.error("Error al obtener personajes:", error);
    }
}

document.getElementById("btn-get-all").addEventListener("click", obtenerAnimesDeTemporada);

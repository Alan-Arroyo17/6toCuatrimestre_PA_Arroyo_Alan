<?php
    require_once('../config/connection.php');
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'OPTIONS') {
        http_response_code(200);
        echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
        $conn->close();
        exit;
    }

    switch($method){
        case 'GET':
            if(isset($_GET['n'])){
                $n = intval($_GET['n']);
                $pares = array();
                for($i = 0; $i <= $n; $i += 2){
                    $pares[] = $i;
                }
                http_response_code(200);
                echo json_encode(array("pares" => $pares));
            }else{
                http_response_code(400);
                echo json_encode(array("mensaje" => "Parámetro 'n' no proporcionado"));
            }
            break;
    }
?>    
<?php
    require_once('../config/connection.php');
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'OPTIONS') {
        http_response_code(200);
        echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
        $conn->close();
        exit;
    }

    switch($method){
        case 'GET':
            if(isset($_GET['id'])){
                $id = intval($_GET['id']);
                $stmt = $conn->prepare("SELECT * FROM alumnos WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $resultado = $stmt->get_result();

                if ($resultado->num_rows > 0) {
                    http_response_code(200);
                    echo json_encode($resultado->fetch_assoc());
                } else {
                    http_response_code(404);
                    echo json_encode(array("mensaje" => "Alumno no encontrado"));
                }
                $stmt->close();

            }elseif(isset($_GET['apellido_paterno']) || isset($_GET['apellido_materno'])){
                $apellido_paterno = isset($_GET['apellido_paterno']) ? trim($_GET['apellido_paterno']) : '';
                $apellido_materno = isset($_GET['apellido_materno']) ? trim($_GET['apellido_materno']) : '';
                $stmt = $conn->prepare("SELECT * FROM alumnos WHERE apellido_paterno LIKE ? OR apellido_materno LIKE ?");
                $apellido_paterno_param = "%" . $apellido_paterno . "%";
                $apellido_materno_param = "%" . $apellido_materno . "%";
                $stmt->bind_param("ss", $apellido_paterno_param, $apellido_materno_param);
                $stmt->execute();
                $resultado = $stmt->get_result();

                if ($resultado->num_rows > 0) {
                    http_response_code(200);
                    echo json_encode($resultado->fetch_all(MYSQLI_ASSOC));
                } else {
                    http_response_code(404);
                    echo json_encode(array("mensaje" => "Alumno no encontrado"));
                }
                $stmt->close();
            }elseif(isset($_GET['id']) && (isset($_GET['apellido_paterno']) || isset($_GET['apellido_materno']))){
                $id = intval($_GET['id']);
                $apellido_paterno = trim($_GET['apellido_paterno']);
                $apellido_materno = trim($_GET['apellido_materno']);
                $stmt = $conn->prepare("SELECT * FROM alumnos WHERE id = ? AND (apellido_paterno LIKE ? OR apellido_materno LIKE ?)");
                $id_param = $id;
                $apellido_paterno_param = "%" . $apellido_paterno . "%";
                $apellido_materno_param = "%" . $apellido_materno . "%";
                $stmt->bind_param("is", $id_param, $apellido_paterno_param, $apellido_materno_param);
                $stmt->execute();
                $resultado = $stmt->get_result();

                if ($resultado->num_rows > 0) {
                    http_response_code(200);
                    echo json_encode($resultado->fetch_assoc());
                } else {
                    http_response_code(404);
                    echo json_encode(array("mensaje" => "Alumno no encontrado"));
                }
                $stmt->close();
            }else{
                $stmt = $conn->prepare("SELECT * FROM alumnos");
                $stmt->execute();
                $resultado = $stmt->get_result();

                if ($resultado->num_rows > 0) {
                    http_response_code(200);
                    echo json_encode($resultado->fetch_all(MYSQLI_ASSOC));
                } else {
                    http_response_code(404);
                    echo json_encode(array("mensaje" => "No hay alumnos registrados"));
                }
                $stmt->close();
            }
            break;
        case 'POST':
            $data = json_decode(file_get_contents("php://input"), true);
            if(isset($data['matricula']) && isset($data['nombre']) && isset($data['apellido_paterno']) && isset($data['apellido_materno']) && isset($data['correo']) && isset($data['telefono']) && isset($data['fecha_nacimiento']) && isset($data['id_carrera']) && isset($data['cuatrimestre_actual']) && isset($data['estatus'])){
                $matricula = trim($data['matricula']);
                $nombre = trim($data['nombre']);
                $apellido_paterno = trim($data['apellido_paterno']);
                $apellido_materno = trim($data['apellido_materno']);
                $correo = trim($data['correo']);
                $telefono = trim($data['telefono']);
                $fecha_nacimiento = trim($data['fecha_nacimiento']);
                $id_carrera = $data['id_carrera'];
                $cuatrimestre_actual = $data['cuatrimestre_actual'];
                $estatus = $data['estatus'];

                $stmt = $conn->prepare("INSERT INTO alumnos (matricula, nombre, apellido_paterno, apellido_materno, correo, telefono, fecha_nacimiento, id_carrera, cuatrimestre_actual, estatus) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("sssssssiis", $matricula, $nombre, $apellido_paterno, $apellido_materno, $correo, $telefono, $fecha_nacimiento, $id_carrera, $cuatrimestre_actual, $estatus);
                
                if ($stmt->execute()) {
                    http_response_code(201);
                    echo json_encode(array("mensaje" => "Alumno creado exitosamente"));
                } else {
                    http_response_code(500);
                    echo json_encode(array("mensaje" => "Error al crear el alumno"));
                }
                $stmt->close();
            } else {
                http_response_code(400);
                echo json_encode(array("mensaje" => "Faltan datos requeridos para crear el alumno"));
            }   
            break;
        case 'PUT':
            $data = json_decode(file_get_contents("php://input"), true);
            if(isset($data['id']) && isset($data['matricula']) && isset($data['nombre']) && isset($data['apellido_paterno']) && isset($data['apellido_materno']) && isset($data['correo']) && isset($data['telefono']) && isset($data['fecha_nacimiento']) && isset($data['id_carrera']) && isset($data['cuatrimestre_actual']) && isset($data['estatus'])){
                $id = intval($data['id']);
                $matricula = trim($data['matricula']);
                $nombre = trim($data['nombre']);
                $apellido_paterno = trim($data['apellido_paterno']);
                $apellido_materno = trim($data['apellido_materno']);
                $correo = trim($data['correo']);
                $telefono = trim($data['telefono']);
                $fecha_nacimiento = trim($data['fecha_nacimiento']);
                $id_carrera = $data['id_carrera'];
                $cuatrimestre_actual = $data['cuatrimestre_actual'];
                $estatus = $data['estatus'];

                $stmt = $conn->prepare("UPDATE alumnos SET matricula=?, nombre=?, apellido_paterno=?, apellido_materno=?, correo=?, telefono=?, fecha_nacimiento=?, id_carrera=?, cuatrimestre_actual=?, estatus=? WHERE id=?");
                $stmt->bind_param("sssssssiisi", $matricula, $nombre, $apellido_paterno, $apellido_materno, $correo, $telefono, $fecha_nacimiento, $id_carrera, $cuatrimestre_actual, $estatus, $id);
                
                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array("mensaje" => "Alumno actualizado exitosamente"));
                } else {
                    http_response_code(500);
                    echo json_encode(array("mensaje" => "Error al actualizar el alumno"));
                }
                $stmt->close();
            } else {
                http_response_code(400);
                echo json_encode(array("mensaje" => "Faltan datos requeridos para actualizar el alumno"));
            }
            break;
        case 'DELETE':
            if(isset($_GET['id'])){
                $id = intval($_GET['id']);
                $stmt = $conn->prepare("DELETE FROM alumnos WHERE id = ?");
                $stmt->bind_param("i", $id);
                
                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array("mensaje" => "Alumno eliminado exitosamente"));
                } else {
                    http_response_code(500);
                    echo json_encode(array("mensaje" => "Error al eliminar el alumno"));
                }
                $stmt->close();
            } else {
                http_response_code(400);
                echo json_encode(array("mensaje" => "Falta el ID del alumno a eliminar"));
            }
            break;      
        }
?>    
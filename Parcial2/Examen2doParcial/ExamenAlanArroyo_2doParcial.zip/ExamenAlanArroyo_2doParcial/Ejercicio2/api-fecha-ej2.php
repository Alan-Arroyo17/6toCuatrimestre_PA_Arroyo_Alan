<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'OPTIONS') {
        http_response_code(200);
        echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
        $conn->close();
        exit;
    }

    switch($method){
        case 'GET':
            $fecha = date('Y-m-d H:i:s');
            http_response_code(200);
            echo json_encode(array("fecha" => $fecha));
            break;
    }
?>    
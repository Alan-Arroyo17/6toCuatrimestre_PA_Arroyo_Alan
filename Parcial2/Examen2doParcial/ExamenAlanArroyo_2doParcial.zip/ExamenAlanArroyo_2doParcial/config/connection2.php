<?php

    $host = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'todo_app';

    $conn = new mysqli($host, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    $conn->set_charset("utf8mb4");

?>
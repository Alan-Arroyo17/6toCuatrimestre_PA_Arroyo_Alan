<?php
    require_once('../config/connection2.php');
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'OPTIONS') {
        http_response_code(200);
        echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
        $conn->close();
        exit;
    }
    //GET: buscar tareas que contengan el texto en titulo o descripcion, campos de mi BD: id_tarea, titulo, descripcion, estado, fecha_creacion
    switch($method){
            case 'GET':
                if(isset($_GET['texto'])){
                    $texto = $_GET['texto'];
                    $sql = "SELECT * FROM tareas WHERE titulo LIKE ? OR descripcion LIKE ?";
                    $stmt = $conn->prepare($sql);
                    $likeTexto = "%$texto%";
                    $stmt->bind_param("ss", $likeTexto, $likeTexto);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    $tareas = array();
                    while($row = $result->fetch_assoc()){
                        $tareas[] = $row;
                    }
                    http_response_code(200);
                    echo json_encode(array("tareas" => $tareas));
                }else{
                    http_response_code(400);
                    echo json_encode(array("mensaje" => "Parámetro 'texto' no proporcionado"));
                }
                break;
            break;
    }
?>    
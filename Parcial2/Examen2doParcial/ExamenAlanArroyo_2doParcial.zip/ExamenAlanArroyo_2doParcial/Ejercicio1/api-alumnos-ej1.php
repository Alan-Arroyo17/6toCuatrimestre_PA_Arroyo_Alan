<?php
    require_once('../config/connection.php');
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'OPTIONS') {
        http_response_code(200);
        echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
        $conn->close();
        exit;
    }

    switch($method){
        case 'GET':
            if(isset($_GET['id'])){
                $id = intval($_GET['id']);
                $stmt = $conn->prepare("SELECT * FROM alumnos WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $resultado = $stmt->get_result();

                if ($resultado->num_rows > 0) {
                    http_response_code(200);
                    echo json_encode($resultado->fetch_assoc());
                } else {
                    http_response_code(404);
                    echo json_encode(array("mensaje" => "Alumno no encontrado"));
                }
                $stmt->close();

            }elseif(isset($_GET['apellido_paterno']) || isset($_GET['apellido_materno'])){
                $apellido_paterno = isset($_GET['apellido_paterno']) ? trim($_GET['apellido_paterno']) : '';
                $apellido_materno = isset($_GET['apellido_materno']) ? trim($_GET['apellido_materno']) : '';
                $stmt = $conn->prepare("SELECT * FROM alumnos WHERE apellido_paterno LIKE ? OR apellido_materno LIKE ?");
                $apellido_paterno_param = "%" . $apellido_paterno . "%";
                $apellido_materno_param = "%" . $apellido_materno . "%";
                $stmt->bind_param("ss", $apellido_paterno_param, $apellido_materno_param);
                $stmt->execute();
                $resultado = $stmt->get_result();

                if ($resultado->num_rows > 0) {
                    http_response_code(200);
                    echo json_encode($resultado->fetch_all(MYSQLI_ASSOC));
                } else {
                    http_response_code(404);
                    echo json_encode(array("mensaje" => "Alumno no encontrado"));
                }
                $stmt->close();
            }elseif(isset($_GET['id']) && (isset($_GET['apellido_paterno']) || isset($_GET['apellido_materno']))){
                $id = intval($_GET['id']);
                $apellido_paterno = trim($_GET['apellido_paterno']);
                $apellido_materno = trim($_GET['apellido_materno']);
                $stmt = $conn->prepare("SELECT * FROM alumnos WHERE id = ? AND (apellido_paterno LIKE ? OR apellido_materno LIKE ?)");
                $id_param = $id;
                $apellido_paterno_param = "%" . $apellido_paterno . "%";
                $apellido_materno_param = "%" . $apellido_materno . "%";
                $stmt->bind_param("is", $id_param, $apellido_paterno_param, $apellido_materno_param);
                $stmt->execute();
                $resultado = $stmt->get_result();

                if ($resultado->num_rows > 0) {
                    http_response_code(200);
                    echo json_encode($resultado->fetch_assoc());
                } else {
                    http_response_code(404);
                    echo json_encode(array("mensaje" => "Alumno no encontrado"));
                }
                $stmt->close();
            }else{
                $stmt = $conn->prepare("SELECT * FROM alumnos");
                $stmt->execute();
                $resultado = $stmt->get_result();

                if ($resultado->num_rows > 0) {
                    http_response_code(200);
                    echo json_encode($resultado->fetch_all(MYSQLI_ASSOC));
                } else {
                    http_response_code(404);
                    echo json_encode(array("mensaje" => "No hay alumnos registrados"));
                }
                $stmt->close();
            }
    }
?>    
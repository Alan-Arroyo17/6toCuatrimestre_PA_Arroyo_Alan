<?php 
require_once "../config/connection.php";

include_once "../includes/header.php"; 

$stmt = $conn->prepare("SELECT id, nombre FROM roles ORDER BY nombre"); 
    $stmt->execute(); 
    $resultado = $stmt->get_result(); 
    $roles = []; 
    while($row = $resultado->fetch_assoc()){ 
        $roles[] = $row; 
    }
    $stmt->close();



?>

<div class="page-header">
    <h1><i class="fas fa-user-plus"></i> Nuevo Usuario</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<?php if (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="card">
    <form action="save.php" method="POST">
        <div class="form-group">
            <label><i class="fas fa-user"></i> Nombre</label>
            <input type="text" name="nombre" placeholder="Ej: Gabriel" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-user"></i> Apellido</label>
            <input type="text" name="apellido" placeholder="Ej: García Márquez" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-globe"></i> Correo</label>
            <input type="email" name="correo" placeholder="Ej: ejemplo@ejemplo.com" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-user"></i> Contraseña</label>
            <input type="password" name="password" placeholder="Mínimo 6 caracteres" minlength="6" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-user"></i> Telefono</label>
            <input type="text" name="telefono" placeholder="Ej: 981231231" maxlength="20">
        </div>

        <div class="form-group">
            <label><i class="fas fa-tag"></i> Rol</label>
            <select name="id_rol" required>
                <option value="">-- Selecciona un rol --</option>
                <?php
                    
                    foreach($roles as $rol){ 
                        echo "<option value='" . htmlspecialchars($rol['id']) . "'>" . htmlspecialchars($rol['nombre']) . "</option>"; 
                    }
                ?>
            </select>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Guardar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>
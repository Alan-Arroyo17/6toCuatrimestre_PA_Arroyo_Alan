<?php
    require_once "../config/connection.php";

    $stmt = $conn->prepare("SELECT id, nombre, apellido FROM usuarios WHERE activo = 1 ORDER BY nombre");
    $stmt->execute();
    $resultado_usuarios = $stmt->get_result();
    $usuarios = [];
    while ($row = $resultado_usuarios->fetch_assoc()) {
        $usuarios[] = $row;
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT id, titulo FROM libros ORDER BY titulo");
    $stmt->execute();
    $resultado_libros = $stmt->get_result();
    $libros = [];
    while ($row = $resultado_libros->fetch_assoc()) {
        $libros[] = $row;
    }
    $stmt->close();
    $conn->close();
?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-plus-circle"></i> Nuevo Préstamo</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<?php if (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="card">
    <form action="save.php" method="POST">
        <div class="form-group">
            <label><i class="fas fa-user"></i> Usuario</label>
            <select name="id_usuario" required>
                <option value="">-- Selecciona un usuario --</option>
                <?php foreach ($usuarios as $usuario): ?>
                    <option value="<?= htmlspecialchars($usuario["id"]) ?>"><?= htmlspecialchars($usuario["nombre"] . " " . $usuario["apellido"]) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar-alt"></i> Fecha Préstamo</label>
            <input type="date" name="fecha_prestamo" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar-check"></i> Fecha Devolución</label>
            <input type="date" name="fecha_devolucion" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-info-circle"></i> Estado</label>
            <select name="estado" required>
                <option value="">-- Selecciona un estado --</option>
                <option value="prestado">Prestado</option>
                <option value="devuelto">Devuelto</option>
                <option value="retrasado">Retrasado</option>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-book"></i> Libro</label>
            <select name="id_libro" required>
                <option value="">-- Selecciona un libro --</option>
                <?php foreach ($libros as $libro): ?>
                    <option value="<?= htmlspecialchars($libro["id"]) ?>"><?= htmlspecialchars($libro["titulo"]) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-hashtag"></i> Cantidad</label>
            <input type="number" name="cantidad" min="1" value="1" placeholder="Ej: 1" required>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Guardar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>
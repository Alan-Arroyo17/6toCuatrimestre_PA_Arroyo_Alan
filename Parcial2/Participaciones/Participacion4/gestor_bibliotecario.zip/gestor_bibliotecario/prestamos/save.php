<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }

    $id_usuario = intval($_POST["id_usuario"] ?? 0);
    $fecha_prestamo = trim($_POST["fecha_prestamo"] ?? "");
    $fecha_devolucion = trim($_POST["fecha_devolucion"] ?? "");
    $estado = trim($_POST["estado"] ?? "");
    $id_libro = intval($_POST["id_libro"] ?? 0);
    $cantidad = intval($_POST["cantidad"] ?? 0);

    $estados_validos = ["prestado", "devuelto", "retrasado"];
    $prestamo_valido = DateTime::createFromFormat("Y-m-d", $fecha_prestamo);
    $devolucion_valida = DateTime::createFromFormat("Y-m-d", $fecha_devolucion);

    $fecha_prestamo_valida = $prestamo_valido && $prestamo_valido->format("Y-m-d") === $fecha_prestamo;
    $fecha_devolucion_es_valida = $devolucion_valida && $devolucion_valida->format("Y-m-d") === $fecha_devolucion;

    if (
        $id_usuario <= 0 ||
        $id_libro <= 0 ||
        $cantidad <= 0 ||
        !$fecha_prestamo_valida ||
        !$fecha_devolucion_es_valida ||
        !in_array($estado, $estados_validos, true)
    ) {
        header("Location: create.php?error=" . urlencode("Datos inválidos para crear el préstamo"));
        exit;
    }

    if ($fecha_devolucion < $fecha_prestamo) {
        header("Location: create.php?error=" . urlencode("La fecha de devolución no puede ser menor a la fecha de préstamo"));
        exit;
    }

    $conn->begin_transaction();

    $stmt = $conn->prepare("INSERT INTO prestamos (id_usuario, fecha_prestamo, fecha_devolucion, estado) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado);

    if ($stmt->execute()) {
        $id_prestamo = $stmt->insert_id;
        $stmt->close();

        $stmt = $conn->prepare("INSERT INTO detalle_prestamo (id_prestamo, id_libro, cantidad) VALUES (?, ?, ?)");
        $stmt->bind_param("iii", $id_prestamo, $id_libro, $cantidad);
        if (!$stmt->execute()) {
            $error = $stmt->error;
            $stmt->close();
            $conn->rollback();
            $conn->close();
            header("Location: create.php?error=" . urlencode("Error al crear el detalle del préstamo: " . $error));
            exit;
        }
        $stmt->close();

        $conn->commit();
        $conn->close();
        header("Location: index.php?success=" . urlencode("Préstamo creado exitosamente"));
        exit;
    } else {
        $error = $stmt->error;
        $stmt->close();
        $conn->rollback();
        $conn->close();
        header("Location: create.php?error=" . urlencode("Error al crear el préstamo: " . $error));
        exit;
    }
?>
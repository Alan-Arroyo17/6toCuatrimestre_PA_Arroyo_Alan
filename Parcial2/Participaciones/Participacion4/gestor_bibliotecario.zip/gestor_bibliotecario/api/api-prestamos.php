<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"));
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Prestamo no encontrado"));
            }
            $stmt->close();
        } elseif (isset($_GET['usuario'])) {
            $usuario = trim($_GET['usuario']);
            $usuario_param = "%$usuario%";
            $stmt = $conn->prepare("SELECT prestamos.id, prestamos.id_usuario, usuarios.nombre, usuarios.apellido, prestamos.fecha_prestamo, prestamos.fecha_devolucion, prestamos.estado FROM prestamos INNER JOIN usuarios ON prestamos.id_usuario = usuarios.id WHERE usuarios.nombre LIKE ? OR usuarios.apellido LIKE ? ORDER BY prestamos.id");
            $stmt->bind_param("ss", $usuario_param, $usuario_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $prestamos = array();

            while ($row = $resultado->fetch_assoc()) {
                $prestamos[] = $row;
            }

            http_response_code(200);
            echo json_encode($prestamos);
            $stmt->close();
        } elseif (isset($_GET['estado'])) {
            $estado = trim($_GET['estado']);
            $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos WHERE estado = ? ORDER BY id");
            $stmt->bind_param("s", $estado);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $prestamos = array();

            while ($row = $resultado->fetch_assoc()) {
                $prestamos[] = $row;
            }

            http_response_code(200);
            echo json_encode($prestamos);
            $stmt->close();
        } elseif (isset($_GET['atrasados']) && strtolower(trim($_GET['atrasados'])) === 'true') {
            $estado_no_devuelto = 'devuelto';
            $hoy = date('Y-m-d');
            $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos WHERE fecha_devolucion < ? AND estado <> ? ORDER BY id");
            $stmt->bind_param("ss", $hoy, $estado_no_devuelto);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $prestamos = array();

            while ($row = $resultado->fetch_assoc()) {
                $prestamos[] = $row;
            }

            http_response_code(200);
            echo json_encode($prestamos);
            $stmt->close();
        } else {
            $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $prestamos = array();

            while ($row = $resultado->fetch_assoc()) {
                $prestamos[] = $row;
            }

            http_response_code(200);
            echo json_encode($prestamos);
            $stmt->close();
        }
        $conn->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
}

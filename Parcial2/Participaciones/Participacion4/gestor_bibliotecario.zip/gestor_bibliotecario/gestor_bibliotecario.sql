CREATE DATABASE IF NOT EXISTS gestor_biblioteca;
USE gestor_biblioteca;

-- =====================================
-- TABLA: roles
-- =====================================

CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE
);

-- =====================================
-- TABLA: usuarios
-- =====================================

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    correo VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    telefono VARCHAR(20),
    id_rol INT NOT NULL,
    activo BOOLEAN DEFAULT TRUE,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_usuario_rol
        FOREIGN KEY (id_rol)
        REFERENCES roles(id)
);

-- =====================================
-- TABLA: categorias
-- =====================================

CREATE TABLE categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    descripcion TEXT
);

-- =====================================
-- TABLA: autores
-- =====================================

CREATE TABLE autores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    nacionalidad VARCHAR(100),
    fecha_nacimiento DATE
);

-- =====================================
-- TABLA: libros
-- =====================================

CREATE TABLE libros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    isbn VARCHAR(20) NOT NULL UNIQUE,
    anio_publicacion YEAR,
    editorial VARCHAR(150),
    cantidad INT NOT NULL DEFAULT 0,
    disponibles INT NOT NULL DEFAULT 0,
    id_categoria INT NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_libro_categoria
        FOREIGN KEY (id_categoria)
        REFERENCES categorias(id)
);

-- =====================================
-- TABLA: libro_autor
-- RELACIÓN MUCHOS A MUCHOS
-- =====================================

CREATE TABLE libro_autor (
    id_libro INT NOT NULL,
    id_autor INT NOT NULL,

    PRIMARY KEY (id_libro, id_autor),

    CONSTRAINT fk_la_libro
        FOREIGN KEY (id_libro)
        REFERENCES libros(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_la_autor
        FOREIGN KEY (id_autor)
        REFERENCES autores(id)
        ON DELETE CASCADE
);

-- =====================================
-- TABLA: prestamos
-- =====================================

CREATE TABLE prestamos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    fecha_prestamo DATE NOT NULL,
    fecha_devolucion DATE NOT NULL,
    estado ENUM('prestado', 'devuelto', 'retrasado')
        DEFAULT 'prestado',

    CONSTRAINT fk_prestamo_usuario
        FOREIGN KEY (id_usuario)
        REFERENCES usuarios(id)
);

-- =====================================
-- TABLA: detalle_prestamo
-- =====================================

CREATE TABLE detalle_prestamo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_prestamo INT NOT NULL,
    id_libro INT NOT NULL,
    cantidad INT NOT NULL DEFAULT 1,

    CONSTRAINT fk_detalle_prestamo
        FOREIGN KEY (id_prestamo)
        REFERENCES prestamos(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_detalle_libro
        FOREIGN KEY (id_libro)
        REFERENCES libros(id)
);

-- =====================================
-- DATOS INICIALES
-- =====================================

INSERT INTO roles(nombre)
VALUES
('Administrador'),
('Bibliotecario');

INSERT INTO categorias(nombre, descripcion)
VALUES
('Programación', 'Libros relacionados con desarrollo de software'),
('Bases de Datos', 'Libros de SQL y modelado'),
('Redes', 'Libros relacionados con redes y telecomunicaciones');

INSERT INTO autores(nombre, apellido, nacionalidad, fecha_nacimiento)
VALUES
('Robert', 'Martin', 'Estados Unidos', '1952-12-05'),
('Gabriel', 'García Márquez', 'Colombia', '1927-03-06'),
('Bjarne', 'Stroustrup', 'Dinamarca', '1950-12-30');

INSERT INTO libros(
    titulo,
    isbn,
    anio_publicacion,
    editorial,
    cantidad,
    disponibles,
    id_categoria
)
VALUES
(
    'Clean Code',
    '9780132350884',
    2008,
    'Prentice Hall',
    10,
    10,
    1
),
(
    'Cien Años de Soledad',
    '9780307474728',
    1967,
    'Sudamericana',
    5,
    5,
    1
),
(
    'The C++ Programming Language',
    '9780321563842',
    2013,
    'Addison-Wesley',
    7,
    7,
    1
);

INSERT INTO libro_autor(id_libro, id_autor)
VALUES
(1,1),
(2,2),
(3,3);

INSERT INTO usuarios(
    nombre,
    apellido,
    correo,
    password,
    telefono,
    id_rol
)
VALUES
(
    'Mario',
    'Segovia',
    'admin@biblioteca.com',
    '123456',
    '9810000000',
    1
),
(
    'Juan',
    'Pérez',
    'juan@biblioteca.com',
    '123456',
    '9811111111',
    2
);

INSERT INTO roles(nombre)
VALUES
('Auxiliar'),
('Invitado');

INSERT INTO categorias(nombre, descripcion)
VALUES
('Inteligencia Artificial', 'Modelos, aprendizaje automatico y aplicaciones practicas'),
('Seguridad Informatica', 'Criptografia, hardening y seguridad ofensiva/defensiva'),
('Arquitectura de Software', 'Patrones, diseno y sistemas distribuidos'),
('DevOps', 'Integracion continua, despliegues y observabilidad');

INSERT INTO autores(nombre, apellido, nacionalidad, fecha_nacimiento)
VALUES
('Martin', 'Fowler', 'Reino Unido', '1963-12-18'),
('Eric', 'Evans', 'Estados Unidos', '1962-08-12'),
('Andrew', 'Tanenbaum', 'Paises Bajos', '1944-03-16'),
('Donald', 'Knuth', 'Estados Unidos', '1938-01-10'),
('Brene', 'Brown', 'Estados Unidos', '1965-11-18'),
('Nassim', 'Taleb', 'Libano', '1960-09-12'),
('Kent', 'Beck', 'Estados Unidos', '1961-03-31');

INSERT INTO libros(
    titulo,
    isbn,
    anio_publicacion,
    editorial,
    cantidad,
    disponibles,
    id_categoria
)
VALUES
('Refactoring', '9780134757599', 2018, 'Addison-Wesley', 8, 8, 6),
('Domain-Driven Design', '9780321125217', 2003, 'Addison-Wesley', 6, 6, 6),
('Modern Operating Systems', '9780133591620', 2014, 'Pearson', 4, 4, 3),
('The Art of Computer Programming Vol. 1', '9780201896831', 1997, 'Addison-Wesley', 3, 3, 1),
('Hands-On Machine Learning', '9781098125974', 2022, 'O''Reilly Media', 7, 7, 4),
('The Phoenix Project', '9781942788294', 2018, 'IT Revolution', 9, 9, 7),
('The Pragmatic Programmer', '9780135957059', 2019, 'Addison-Wesley', 10, 10, 6);

INSERT INTO libro_autor(id_libro, id_autor)
VALUES
(4,4),
(5,5),
(6,6),
(7,7),
(8,1),
(9,10),
(10,3);

INSERT INTO usuarios(
    nombre,
    apellido,
    correo,
    password,
    telefono,
    id_rol
)
VALUES
('Ana', 'Lopez', 'ana.lopez@biblioteca.com', '123456', '9812222222', 2),
('Carlos', 'Mendez', 'carlos.mendez@biblioteca.com', '123456', '9813333333', 3),
('Sofia', 'Ramirez', 'sofia.ramirez@biblioteca.com', '123456', '9814444444', 2),
('Diego', 'Hernandez', 'diego.hernandez@biblioteca.com', '123456', '9815555555', 4),
('Laura', 'Martinez', 'laura.martinez@biblioteca.com', '123456', '9816666666', 1),
('Pedro', 'Santos', 'pedro.santos@biblioteca.com', '123456', '9817777777', 3),
('Elena', 'Cruz', 'elena.cruz@biblioteca.com', '123456', '9818888888', 2);

INSERT INTO prestamos(
    id_usuario,
    fecha_prestamo,
    fecha_devolucion,
    estado
)
VALUES
(1, '2026-05-15', '2026-05-22', 'devuelto'),
(2, '2026-05-20', '2026-05-30', 'devuelto'),
(3, '2026-06-01', '2026-06-10', 'prestado'),
(4, '2026-06-05', '2026-06-12', 'retrasado'),
(5, '2026-06-08', '2026-06-15', 'prestado'),
(6, '2026-06-10', '2026-06-18', 'devuelto'),
(7, '2026-06-12', '2026-06-20', 'prestado'),
(8, '2026-06-14', '2026-06-21', 'prestado');

INSERT INTO detalle_prestamo(
    id_prestamo,
    id_libro,
    cantidad
)
VALUES
(1, 1, 1),
(2, 2, 1),
(3, 5, 1),
(4, 9, 2),
(5, 8, 1),
(6, 3, 1),
(7, 10, 1),
(8, 4, 1);
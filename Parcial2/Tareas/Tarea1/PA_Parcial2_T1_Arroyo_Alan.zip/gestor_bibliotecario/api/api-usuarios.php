<?php
    require_once('../config/connection.php');

    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    $method = $_SERVER['REQUEST_METHOD'];

    switch($method){
        case 'GET':
            //Obtener usuario por ID
            if(isset($_GET['id'])){
                $idusuario = intval($_GET['id']);
                $stmt = $conn->prepare("SELECT u.id, u.nombre, u.apellido, u.correo, u.telefono, r.nombre AS rol FROM usuarios u INNER JOIN roles r ON u.id_rol = r.id WHERE u.id = ?");
                $stmt->bind_param("i", $idusuario);
                $stmt->execute();
                $resultado = $stmt->get_result();
                if($resultado->num_rows > 0){
                    $usuarios = $resultado->fetch_assoc();
                    echo json_encode($usuarios);
                }else{
                    echo json_encode(array("mensaje" => "Usuario no encontrado"));
                }
                $stmt->close();
                $conn->close();

            //Obtener usuario por nombre
            }elseif(isset($_GET['nombre'])){
                $nombre = $_GET['nombre'];
                $stmt = $conn->prepare("SELECT u.id, u.nombre, u.apellido, u.correo, u.telefono, r.nombre AS rol FROM usuarios u INNER JOIN roles r ON u.id_rol = r.id WHERE u.nombre = ?");
                $stmt->bind_param("s", $nombre);
                $stmt->execute();
                $resultado = $stmt->get_result();
                if($resultado->num_rows > 0){
                    $usuarios = array();
                    while($row = $resultado->fetch_assoc()){
                        $usuarios[] = $row;
                    }
                    echo json_encode($usuarios);
                }else{
                    echo json_encode(array("mensaje" => "Usuario no encontrado"));
                }
                $stmt->close();
                $conn->close();

            //Obtener usuario por correo
            }elseif(isset($_GET['correo'])){
                $correo = $_GET['correo'];
                $stmt = $conn->prepare("SELECT u.id, u.nombre, u.apellido, u.correo, u.telefono, r.nombre AS rol FROM usuarios u INNER JOIN roles r ON u.id_rol = r.id WHERE u.correo = ?");
                $stmt->bind_param("s", $correo);
                $stmt->execute();
                $resultado = $stmt->get_result();
                if($resultado->num_rows > 0){
                    $usuario = $resultado->fetch_assoc();
                    echo json_encode($usuario);
                }else{
                    echo json_encode(array("mensaje" => "Correo no encontrado"));
                }
                $stmt->close();
                $conn->close();

            //Usuarios activos
            }elseif(isset($_GET['estado'])){
                $stmt = $conn->prepare("SELECT u.id, u.nombre, u.apellido, u.correo, u.telefono, r.nombre AS rol FROM usuarios u INNER JOIN roles r ON u.id_rol = r.id WHERE u.activo = TRUE");
                $stmt->execute();
                $resultado = $stmt->get_result();
                if($resultado->num_rows > 0){
                    $usuarios = array();
                    while($row = $resultado->fetch_assoc()){
                        $usuarios[] = $row;
                    }
                    echo json_encode($usuarios);
                }else{
                    echo json_encode(array("mensaje" => "No se encontraron usuarios activos"));
                }
                $stmt->close();
                $conn->close();

            //Obtener todos los usuarios
            }else{
                $stmt = $conn->prepare("SELECT u.id, u.nombre, u.apellido, u.correo, u.telefono, r.nombre AS rol FROM usuarios u INNER JOIN roles r ON u.id_rol = r.id");
                $stmt->execute();
                $resultado = $stmt->get_result();
                if($resultado->num_rows > 0){
                    $usuarios = array();
                    while($row = $resultado->fetch_assoc()){
                        $usuarios[] = $row;
                    }
                    echo json_encode($usuarios);
                }else{
                    echo json_encode(array("mensaje" => "No existen usuarios registrados"));
                }
                $stmt->close();
                $conn->close();
            }
            break;
    }
?>
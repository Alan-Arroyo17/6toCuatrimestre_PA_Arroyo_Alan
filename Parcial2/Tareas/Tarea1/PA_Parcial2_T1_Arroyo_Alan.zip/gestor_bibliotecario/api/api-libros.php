<?php
    require_once('../config/connection.php'); // Importa la conexión a la base de datos
    // Configuración de encabezados HTTP
    header("Access-Control-Allow-Origin: *"); // Permite que cualquier origen pueda acceder a esta API, sin importar su dominio. Esto nos va a ayudar a prevenir los famosos problemas de CORS (Cross-Origin Resource Sharing). ¿Qué es CORS? CORS es una política de seguridad implementada por los navegadores web para restringir las solicitudes HTTP que se puedan hacer a un dominio diferente al que sirvió la página web.
    header("Content-Type: application/json; charset=UTF-8"); // Esta cabecer, indica el tipo de contenido que va a ser devuelto por esta API, para este ejemplo, va ser en formato JSON. Además, también especificamos la encodificación de caracteres, en este caso UTF-8.
    header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE"); // Esta cabecera especifica los métodos HTTP que esta API va a aceptar. Es una cabecera importante para temas de seguridad. ¿Qué ocurre si un cliente intenta hacer una solicitud no permitida? En este caso, el servidor responderá con un código de estado HTTP 405 Method Not Allowed, indicando que el método utilizado en la solicitud no está permitido para el recurso solicitado.
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With"); // Esta cabecera especifica los encabezados HTTP que se permitirán en las solicitudes o peticiones recibidas por esta API. Es decir, si un cliente hace una solicitud a esta API, y envía una cabecer no permitida, el servidor responderá con un código de estado HTTP 400 Bad Request, indicando que la solicitud no se pudo procesar debido a encabezados no permitidos.

    // Obtener el método HTTP de la solicitud
    $method = $_SERVER['REQUEST_METHOD']; // Defino una variable, en este caso yo la definí como "method" (Ojo, no importa el nombre que tú coloques). En esta variable estoy almacenando el método HTTP que se utilizó para hacer la solicitud a esta API. ¿Cómo hago esto? Lo hago utilizando la superglobal $_SERVER, que se comporta como un arreglo asociativo que contiene información sobre el servidor y la solicitud actual. La clave 'REQUEST_METHOD' dentro de $_SERVER nos devuelve el método HTTP utilizado en la solicitud (Que por ende, puede ser GET, POST, PUT, PATCH o DELETE).

    // Procesamos la solicitud según el método HTTP
    switch ($method) { // Utilizamos la condicional switch-case para evaluar el valor de la variable $method. NOTA: Técnicamente igual podríamos utilizar una estructura if-else, sin embargo el switch-case es un método más limpio
        case 'GET':
            if (isset($_GET['titulo'])) { 
                $titulo = $_GET['titulo']; 
                $stmt = $conn->prepare("SELECT id, titulo FROM libros WHERE titulo = ?");
                $stmt->bind_param("s", $titulo);
                $stmt->execute();
                $resultado = $stmt->get_result();
                if ($resultado->num_rows > 0) {
                    $libro = $resultado->fetch_assoc();
                    echo json_encode($libro);
                } else {
                    echo json_encode(array("mensaje" => "Titulo no encontrado"));
                }
                $stmt->close();
                $conn->close();
                
            }elseif(isset($_GET['disponibles'])){
                $stmt = $conn->prepare("SELECT id, titulo, disponibles FROM libros WHERE disponibles > 0");
                $stmt->execute();
                $resultado = $stmt->get_result();
                $libros = array();
                if ($resultado->num_rows > 0) {
                    while ($row = $resultado->fetch_assoc()) {
                        $libros[] = $row;
                    }
                    echo json_encode($libros);
                }else{
                    echo json_encode(array("mensaje" => "No hay libros disponibles."));
                }
                $stmt->close();
                $conn->close();

            }elseif (isset($_GET['anio_publicacion'])) {
                $anio = intval($_GET['anio_publicacion']);
                $stmt = $conn->prepare("SELECT id, titulo, anio_publicacion FROM libros WHERE anio_publicacion = ? ");
                $stmt->bind_param("i", $anio);  
                $stmt->execute();
                $resultado = $stmt->get_result();
                $libros = array();
                if ($resultado->num_rows > 0) {
                    while ($row = $resultado->fetch_assoc()) {
                        $libros[] = $row;
                    }
                    echo json_encode($libros);
                } else {
                    echo json_encode(array("mensaje" => "No se encontraron libros publicados en ese año."));
                }
                $stmt->close();
                $conn->close();

            }elseif(isset($_GET['categoria'])){
                $categoria = $_GET['categoria'];
                $stmt = $conn->prepare("SELECT l.id, l.titulo, c.nombre AS categoria FROM libros l INNER JOIN categorias c ON l.id_categoria = c.id WHERE c.nombre = ?");
                $stmt->bind_param("s", $categoria);
                $stmt->execute();
                $resultado = $stmt->get_result();
                $libros = array();
                if ($resultado->num_rows > 0) {
                    while ($row = $resultado->fetch_assoc()) {
                        $libros[] = $row;
                    }
                    echo json_encode($libros);
                } else {
                    echo json_encode(array("mensaje" => "No se encontraron libros para esa categoría"));
                }
                $stmt->close();
                $conn->close();

            }elseif(isset($_GET['editorial'])){
                $editorial = $_GET['editorial'];
                $stmt = $conn->prepare("SELECT id, titulo, editorial FROM libros WHERE editorial = ?");
                $stmt->bind_param("s", $editorial);
                $stmt->execute();
                $resultado = $stmt->get_result();
                $libros = array();
                if ($resultado->num_rows > 0) {
                    while ($row = $resultado->fetch_assoc()) {
                        $libros[] = $row;
                    }
                    echo json_encode($libros);
                } else {
                    echo json_encode(array("mensaje" => "No se encontraron libros para esa editorial"));
                }
                $stmt->close();
                $conn->close();

            } else { // Operación para obtener todos los registros de la tabla "libros" - http://localhost/gestor_bibliotecario/api/api-libros.php
                $stmt = $conn->prepare("SELECT id, titulo, isbn, editorial, anio_publicacion FROM libros");
                $stmt->execute();
                $resultado = $stmt->get_result();
                if ($resultado->num_rows > 0) {
                    $libros = array();
                    while ($row = $resultado->fetch_assoc()) {
                        $libros[] = $row;
                    }
                    echo json_encode($libros);
                } else {
                    echo json_encode(array("mensaje" => "No existen libros registrados"));
                }
                $stmt->close();
                $conn->close();
            }
            break;
        case 'POST':
            // Bloque de código con estructura y operaciones para manejar solicitudes POST
            // Operación para crear un nuevo registro en la tabla "categorías"
            $data = json_decode(file_get_contents("php://input"), true); // Aquí lo que estoy haciendo es crear una variable llamada $data, y esta variable contiene la decodificación de los datos JSON, que se realiza mediante el método json_decode(). ¿A qué se refiere o para qué me sirve la decodificación? Recuerda que el cliente envía los datos en formato JSON, entonces para poder trabajarlos en nuestro código PHP necesitamos convertirlos de formato JSON a un formato que PHP pueda entender, en este caso usaremos un arreglo asociativo. El método json_decode() hace tal cual eso, convierte una cadena JSON en una estructura de datos de PHP. El parámetro file_get_contents("php://input") se utiliza para leer el cuerpo de la solicitud HTTP, y el parámetro true, indica que el resultado debe ser un arreglo asociativo.
            $data['titulo'] = trim($data['titulo'] ?? "");
            $data['isbn'] = trim($data['isbn'] ?? "");
            $data['anio_publicacion'] = trim($data['anio_publicacion'] ?? "");
            $data['editorial'] = trim($data['editorial'] ?? "");
            $data['cantidad'] = trim($data['cantidad'] ?? "");
            $data['disponibles'] = trim($data['disponibles'] ?? "");
            $data['id_categoria'] = trim($data['id_categoria'] ?? "");

            if(!empty($data['titulo']) && !empty($data['isbn']) && !empty($data['anio_publicacion']) && !empty($data['editorial']) && !empty($data['cantidad']) && !empty($data['disponibles']) && !empty($data['id_categoria'])){
                $stmt = $conn->prepare("INSERT INTO libros (titulo, isbn, anio_publicacion, editorial, cantidad, disponibles, id_categoria) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("sssssii", $data['titulo'], $data['isbn'], $data['anio_publicacion'], $data['editorial'], $data['cantidad'], $data['disponibles'], $data['id_categoria']);
                if($stmt->execute()){
                    http_response_code(201);
                    echo json_encode(array("mensaje" => "Libro creado exitosamente"));
                } else {
                    echo json_encode(array("mensaje" => "Error al crear el libro"));
                }
                $stmt->close();
                $conn->close();
            } else {
                echo json_encode(array("mensaje" => "Todos los campos son obligatorios"));
            }
            break;
        case 'PUT':
            // Bloque de código con estructura y operaciones para manejar solicitudes PUT
            break;
        case 'PATCH':
            // Bloque de código con estructura y operaciones para manejar solicitudes PATCH
            break;
        case 'DELETE':
            // Bloque de código con estructura y operaciones para manejar solicitudes DELETE
            break;
        default:
            // Mensajito por si no cae en ninguna de los casos anteriores
            break;
    }
?>
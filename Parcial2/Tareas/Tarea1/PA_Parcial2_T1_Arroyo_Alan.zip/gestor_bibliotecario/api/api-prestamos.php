<?php
    require_once('../config/connection.php');

    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    $method = $_SERVER['REQUEST_METHOD'];

    switch($method){
        case 'GET':
            //Obtener préstamo por ID
            if(isset($_GET['id'])){
                $id = intval($_GET['id']);
                $stmt = $conn->prepare("SELECT p.id, u.nombre, u.apellido, l.titulo, p.fecha_prestamo, p.fecha_devolucion, p.estado FROM prestamos p INNER JOIN usuarios u ON p.id_usuario = u.id INNER JOIN detalle_prestamo d ON p.id = d.id_prestamo INNER JOIN libros l ON d.id_libro = l.id WHERE p.id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $resultado = $stmt->get_result();
                if($resultado->num_rows > 0){
                    $prestamos = $resultado->fetch_assoc();
                    echo json_encode($prestamos);
                }else{
                    echo json_encode(array("mensaje" => "Préstamo no encontrado"));
                }
                $stmt->close();
                $conn->close();

            //Obtener préstamo por usuario
            }elseif(isset($_GET['usuario'])){
                $usuario = $_GET['usuario'];
                $stmt = $conn->prepare("SELECT p.id, u.nombre, u.apellido, l.titulo, p.fecha_prestamo, p.fecha_devolucion, p.estado FROM prestamos p INNER JOIN usuarios u ON p.id_usuario = u.id INNER JOIN detalle_prestamo d ON p.id = d.id_prestamo INNER JOIN libros l ON d.id_libro = l.id WHERE u.nombre = ?");
                $stmt->bind_param("s", $usuario);
                $stmt->execute();
                $resultado = $stmt->get_result();
                if($resultado->num_rows > 0){
                    $prestamos = array();
                    while($row = $resultado->fetch_assoc()){
                        $prestamos[] = $row;
                    }
                    echo json_encode($prestamos);
                }else{
                    echo json_encode(array("mensaje" => "Usuario no encontrado"));
                }
                $stmt->close();
                $conn->close();

            //Obtener préstamo por estado
            }elseif(isset($_GET['estado'])){
                $estado = $_GET['estado'];
                $stmt = $conn->prepare("SELECT p.id, u.nombre, u.apellido, l.titulo, p.estado FROM prestamos p INNER JOIN usuarios u ON p.id_usuario = u.id INNER JOIN detalle_prestamo d ON p.id = d.id_prestamo INNER JOIN libros l ON d.id_libro = l.id WHERE p.estado = ?");
                $stmt->bind_param("s", $estado);
                $stmt->execute();
                $resultado = $stmt->get_result();
                if($resultado->num_rows > 0){
                    $prestamos = array();
                    while($row = $resultado->fetch_assoc()){
                        $prestamos[] = $row;
                    }
                    echo json_encode($prestamos);
                }else{
                    echo json_encode(array("mensaje" => "Estado no encontrado"));
                }
                $stmt->close();
                $conn->close();

            //Obtener todos los préstamos
            }else{
                $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos");
                $stmt->execute();
                $resultado = $stmt->get_result();
                if($resultado->num_rows > 0){
                    $prestamos = array();
                    while($row = $resultado->fetch_assoc()){
                        $prestamos[] = $row;
                    }
                    echo json_encode($prestamos);
                }else{
                    echo json_encode(array("mensaje" => "No existen préstamos registrados"));
                }
                $stmt->close();
                $conn->close();
            }
            break;
    }
?>
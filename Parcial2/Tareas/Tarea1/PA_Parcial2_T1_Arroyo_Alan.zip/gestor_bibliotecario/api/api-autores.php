<?php
    require_once('../config/connection.php');

    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    $method = $_SERVER['REQUEST_METHOD'];

    switch($method){
        case 'GET':
            //Obtener usuario por ID
            if(isset($_GET['id'])){
                $idautor = intval($_GET['id']);
                $stmt=$conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE id = ?");
                $stmt->bind_param("i", $idautor);
                $stmt->execute();
                $resultado=$stmt->get_result();
                if($resultado->num_rows>0){
                    $autores=$resultado->fetch_assoc();
                    echo json_encode($autores);
                }else{
                    echo json_encode(array("mensaje" => "Autor no encontrado"));
                }
                $stmt->close();
                $conn->close();

            //Obtener autor por nombre
            }elseif(isset($_GET['nombre'])){
                $nombre = $_GET['nombre'];
                $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE nombre = ?");
                $stmt->bind_param("s", $nombre);
                $stmt->execute();
                $resultado=$stmt->get_result();
                if($resultado->num_rows>0){
                    $nusuario=$resultado->fetch_assoc();
                    echo json_encode($nusuario);
                }else{
                    echo json_encode(array("mensaje" => "Autor no encontrado"));
                }
                $stmt->close();
                $conn->close();

            //Obtener autor por nacionalidad
            }elseif(isset($_GET['nacionalidad'])){
                $na_autor = $_GET['nacionalidad'];
                $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE nacionalidad = ?");
                $stmt->bind_param("s", $na_autor);
                $stmt->execute();
                $resultado=$stmt->get_result();
                if($resultado->num_rows>0){
                    $nacionalidad=$resultado->fetch_assoc();
                    echo json_encode($nacionalidad);
                }else{
                    echo json_encode(array("mensaje" => "Autor no encontrado"));
                }
                $stmt->close();
                $conn->close();

            //Autores nacidos después de cierta fecha
            }elseif(isset($_GET['fecha_nacimiento'])){
                $fechanac = $_GET['fecha_nacimiento'];
                $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE fecha_nacimiento > ?");
                $stmt->bind_param("s", $fechanac);
                $stmt->execute();
                $resultado = $stmt->get_result();
                if($resultado->num_rows>0){
                    $autores = array();
                    while($row = $resultado->fetch_assoc()){
                        $autores[] = $row;
                    }
                    echo json_encode($autores);
                }else{
                    echo json_encode(array("mensaje" => "No se encontraron resultados"));
                }
                $stmt->close();
                $conn->close();

            //Obtener todos los usuarios
            }else{
                $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores");
                $stmt->execute();
                $resultado=$stmt->get_result();
                if($resultado->num_rows>0){
                    $autores = array();
                    while ($row = $resultado->fetch_assoc()) {
                        $autores[] = $row;
                    }
                    echo json_encode($autores);
                }else{
                    echo json_encode(array("mensaje" => "No existen autores registrados"));
                }
            }
            break;
    }
?>
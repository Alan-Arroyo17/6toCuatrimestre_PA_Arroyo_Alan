<?php
    require_once('../config/connection.php');

    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    $method = $_SERVER['REQUEST_METHOD'];

    switch($method){
        case 'GET':
            //Buscar por ID
            if(isset($_GET['id'])){
                $id = intval($_GET['id']);
                $stmt = $conn->prepare("SELECT dp.id, dp.id_prestamo, p.fecha_prestamo, dp.id_libro, l.titulo, dp.cantidad FROM detalle_prestamo dp INNER JOIN prestamos p ON dp.id_prestamo = p.id INNER JOIN libros l ON dp.id_libro = l.id WHERE dp.id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $resultado = $stmt->get_result();
                if($resultado->num_rows > 0){
                    $detalles = $resultado->fetch_assoc();
                    echo json_encode($detalles);
                }else{
                    echo json_encode(array("mensaje" => "Detalle de préstamo no encontrado"));
                }
                $stmt->close();
                $conn->close();

            //Buscar por préstamo
            }elseif(isset($_GET['id_prestamo'])){
                $id = intval($_GET['id_prestamo']);
                $stmt = $conn->prepare("SELECT dp.id, dp.id_prestamo, p.fecha_prestamo, dp.id_libro, l.titulo, dp.cantidad FROM detalle_prestamo dp INNER JOIN prestamos p ON dp.id_prestamo = p.id INNER JOIN libros l ON dp.id_libro = l.id WHERE dp.id_prestamo = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $resultado = $stmt->get_result();
                if($resultado->num_rows > 0){
                    $detalles = array();
                    while($row = $resultado->fetch_assoc()){
                        $detalles[] = $row;
                    }
                    echo json_encode($detalles);
                }else{
                    echo json_encode(array("mensaje" => "No se encontraron detalles para este préstamo"));
                }
                $stmt->close();
                $conn->close();

            //Buscar por libro
            }elseif(isset($_GET['titulo'])){
                $titulo = $_GET['titulo'];
                $stmt = $conn->prepare("SELECT dp.id, dp.id_prestamo, p.fecha_prestamo, dp.id_libro, l.titulo, dp.cantidad FROM detalle_prestamo dp INNER JOIN prestamos p ON dp.id_prestamo = p.id INNER JOIN libros l ON dp.id_libro = l.id WHERE l.titulo = ?");
                $stmt->bind_param("s", $titulo);
                $stmt->execute();
                $resultado = $stmt->get_result();
                if($resultado->num_rows > 0){
                    $libros = array();
                    while($row = $resultado->fetch_assoc()){
                        $libros[] = $row;
                    }
                    echo json_encode($libros);
                }else{
                    echo json_encode(array("mensaje" => "Libro no encontrado"));
                }
                $stmt->close();
                $conn->close();

            //Obtener todos los registros
            }else{
                $stmt = $conn->prepare("SELECT dp.id, dp.id_prestamo, p.fecha_prestamo, dp.id_libro, l.titulo, dp.cantidad FROM detalle_prestamo dp INNER JOIN prestamos p ON dp.id_prestamo = p.id INNER JOIN libros l ON dp.id_libro = l.id");
                $stmt->execute();
                $resultado = $stmt->get_result();
                if($resultado->num_rows > 0){
                    $detalles = array();
                    while($row = $resultado->fetch_assoc()){
                        $detalles[] = $row;
                    }
                    echo json_encode($detalles);
                }else{
                    echo json_encode(array("mensaje" => "No existen registros de detalles de préstamo"));
                }
                $stmt->close();
                $conn->close();
            }
            break;
    }
?>
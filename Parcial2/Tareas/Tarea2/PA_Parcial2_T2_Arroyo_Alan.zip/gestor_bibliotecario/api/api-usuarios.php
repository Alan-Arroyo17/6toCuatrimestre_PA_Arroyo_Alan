<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"));
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Usuario no encontrado"));
            }
            $stmt->close();
        } elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $nombre_param = "%$nombre%";
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE nombre LIKE ? ORDER BY id");
            $stmt->bind_param("s", $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        } elseif (isset($_GET['correo'])) {
            $correo = trim($_GET['correo']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE correo = ? ORDER BY id");
            $stmt->bind_param("s", $correo);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        } elseif (isset($_GET['id_rol'])) {
            $id_rol = intval($_GET['id_rol']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE id_rol = ? ORDER BY id");
            $stmt->bind_param("i", $id_rol);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        } else {
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        }
        $conn->close();
        break;
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);

        if (isset($data['nombre'], $data['apellido'], $data['correo'], $data['telefono'], $data['id_rol'])) {
            $nombre = trim($data['nombre']);
            $apellido = trim($data['apellido']);
            $correo = trim($data['correo']);
            $telefono = trim($data['telefono']);
            $id_rol = intval($data['id_rol']);

            $stmt = $conn->prepare("INSERT INTO usuarios (nombre, apellido, correo, telefono, id_rol) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssi", $nombre, $apellido, $correo, $telefono, $id_rol);

            if ($stmt->execute()) {
                http_response_code(201);
                echo json_encode(array("mensaje" => "Usuario creado exitosamente", "id" => $stmt->insert_id));
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al crear el usuario"));
            }
            $stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Datos incompletos para crear el usuario"));
        }
        $conn->close();
        break;
    case 'PUT':
        $data = json_decode(file_get_contents("php://input"), true);

        if (isset($data['id'], $data['nombre'], $data['apellido'], $data['correo'], $data['telefono'], $data['id_rol'])) {
            $id = intval($data['id']);
            $nombre = trim($data['nombre']);
            $apellido = trim($data['apellido']);
            $correo = trim($data['correo']);
            $telefono = trim($data['telefono']);
            $id_rol = intval($data['id_rol']);

            $stmt = $conn->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ?, telefono = ?, id_rol = ? WHERE id = ?");
            $stmt->bind_param("ssssii", $nombre, $apellido, $correo, $telefono, $id_rol, $id);

            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("mensaje" => "Usuario actualizado exitosamente"));
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al actualizar el usuario"));
            }
            $stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Datos incompletos para actualizar el usuario"));
        }
        $conn->close();
        break;
    case 'PATCH':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);

            if (isset($data['nombre'])) {
                $nombre = trim($data['nombre']);
                $stmt = $conn->prepare("UPDATE usuarios SET nombre = ? WHERE id = ?");
                $stmt->bind_param("si", $nombre, $id);

                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array("mensaje" => "Nombre del usuario actualizado exitosamente"));
                } else {
                    http_response_code(500);
                    echo json_encode(array("mensaje" => "Error al actualizar el nombre del usuario"));
                }
                $stmt->close();
            } else {
                http_response_code(400);
                echo json_encode(array("mensaje" => "Datos incompletos para actualizar el nombre del usuario"));
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "ID del usuario no proporcionado"));
        }
        $conn->close();
        break;
    case 'DELETE':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $id);

            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("mensaje" => "Usuario eliminado exitosamente"));
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al eliminar el usuario"));
            }
            $stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "ID del usuario no proporcionado"));
        }
        $conn->close();
        break;
    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
}

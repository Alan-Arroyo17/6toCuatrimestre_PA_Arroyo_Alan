<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"));
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Prestamo no encontrado"));
            }
            $stmt->close();
        } elseif (isset($_GET['usuario'])) {
            $usuario = trim($_GET['usuario']);
            $usuario_param = "%$usuario%";
            $stmt = $conn->prepare("SELECT prestamos.id, prestamos.id_usuario, usuarios.nombre, usuarios.apellido, prestamos.fecha_prestamo, prestamos.fecha_devolucion, prestamos.estado FROM prestamos INNER JOIN usuarios ON prestamos.id_usuario = usuarios.id WHERE usuarios.nombre LIKE ? OR usuarios.apellido LIKE ? ORDER BY prestamos.id");
            $stmt->bind_param("ss", $usuario_param, $usuario_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $prestamos = array();

            while ($row = $resultado->fetch_assoc()) {
                $prestamos[] = $row;
            }

            http_response_code(200);
            echo json_encode($prestamos);
            $stmt->close();
        } elseif (isset($_GET['estado'])) {
            $estado = trim($_GET['estado']);
            $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos WHERE estado = ? ORDER BY id");
            $stmt->bind_param("s", $estado);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $prestamos = array();

            while ($row = $resultado->fetch_assoc()) {
                $prestamos[] = $row;
            }

            http_response_code(200);
            echo json_encode($prestamos);
            $stmt->close();
        } elseif (isset($_GET['atrasados']) && strtolower(trim($_GET['atrasados'])) === 'true') {
            $estado_no_devuelto = 'devuelto';
            $hoy = date('Y-m-d');
            $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos WHERE fecha_devolucion < ? AND estado <> ? ORDER BY id");
            $stmt->bind_param("ss", $hoy, $estado_no_devuelto);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $prestamos = array();

            while ($row = $resultado->fetch_assoc()) {
                $prestamos[] = $row;
            }

            http_response_code(200);
            echo json_encode($prestamos);
            $stmt->close();
        } else {
            $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $prestamos = array();

            while ($row = $resultado->fetch_assoc()) {
                $prestamos[] = $row;
            }

            http_response_code(200);
            echo json_encode($prestamos);
            $stmt->close();
        }
        $conn->close();
        break;
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);

        if (isset($data['id_usuario'], $data['fecha_prestamo'], $data['fecha_devolucion'], $data['estado'])) {
            $id_usuario = intval($data['id_usuario']);
            $fecha_prestamo = trim($data['fecha_prestamo']);
            $fecha_devolucion = trim($data['fecha_devolucion']);
            $estado = trim($data['estado']);

            $stmt = $conn->prepare("INSERT INTO prestamos (id_usuario, fecha_prestamo, fecha_devolucion, estado) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isss", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado);

            if ($stmt->execute()) {
                http_response_code(201);
                echo json_encode(array("mensaje" => "Prestamo creado exitosamente", "id" => $stmt->insert_id));
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al crear el prestamo"));
            }
            $stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Datos incompletos"));
        }
        $conn->close();
        break;
    case 'PUT':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);

            if (isset($data['id_usuario'], $data['fecha_prestamo'], $data['fecha_devolucion'], $data['estado'])) {
                $id_usuario = intval($data['id_usuario']);
                $fecha_prestamo = trim($data['fecha_prestamo']);
                $fecha_devolucion = trim($data['fecha_devolucion']);
                $estado = trim($data['estado']);

                $stmt = $conn->prepare("UPDATE prestamos SET id_usuario = ?, fecha_prestamo = ?, fecha_devolucion = ?, estado = ? WHERE id = ?");
                $stmt->bind_param("isssi", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado, $id);

                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array("mensaje" => "Prestamo actualizado exitosamente"));
                } else {
                    http_response_code(500);
                    echo json_encode(array("mensaje" => "Error al actualizar el prestamo"));
                }
                $stmt->close();
            } else {
                http_response_code(400);
                echo json_encode(array("mensaje" => "Datos incompletos para actualizar el prestamo"));
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "ID del prestamo no proporcionado"));
        }
        $conn->close();
        break;
    case 'PATCH':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);

            if (isset($data['estado'])) {
                $estado = trim($data['estado']);

                $stmt = $conn->prepare("UPDATE prestamos SET estado = ? WHERE id = ?");
                $stmt->bind_param("si", $estado, $id);

                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array("mensaje" => "Estado del prestamo actualizado exitosamente"));
                } else {
                    http_response_code(500);
                    echo json_encode(array("mensaje" => "Error al actualizar el estado del prestamo"));
                }
                $stmt->close();
            } else {
                http_response_code(400);
                echo json_encode(array("mensaje" => "Estado no proporcionado para actualizar"));
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "ID del prestamo no proporcionado"));
        }
        $conn->close();
        break;
    case 'DELETE':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("DELETE FROM prestamos WHERE id = ?");
            $stmt->bind_param("i", $id);

            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("mensaje" => "Prestamo eliminado exitosamente"));
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al eliminar el prestamo"));
            }
            $stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "ID del prestamo no proporcionado"));
        }
        $conn->close();
        break;
    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
}

const URL_BASE = 'http://localhost/gestor_alumnos/api/';


// Función para mostrar mensajes
function mostrarMensaje(texto, tipo) {
    const mensaje = document.getElementById('mensaje');

    if (!mensaje) {
        return;
    }

    mensaje.innerHTML = texto;

    if (tipo === 'error') {
        mensaje.className = 'mensaje mensaje-error';
    } else {
        mensaje.className = 'mensaje mensaje-exito';
    }
}


// CARRERAS

// GET ../api/api-carreras.php - obtener todas las carreras
async function getCarreras() {
    try {
        const response = await fetch(`${URL_BASE}api-carreras.php`);
        const data = await response.json();

        const filtroCarreraAlumno = document.getElementById('filtroCarreraAlumno');
        const carreraAlumno = document.getElementById('carreraAlumno');
        const filtroCarreraMateria = document.getElementById('filtroCarreraMateria');

        if (filtroCarreraAlumno) {
            filtroCarreraAlumno.innerHTML = '<option value="">Todas las carreras</option>';
        }

        if (carreraAlumno) {
            carreraAlumno.innerHTML = '<option value="">Selecciona una carrera</option>';
        }

        if (filtroCarreraMateria) {
            filtroCarreraMateria.innerHTML = '<option value="">Todas las carreras</option>';
        }

        data.forEach(carrera => {
            if (filtroCarreraAlumno) {
                filtroCarreraAlumno.innerHTML += `
                    <option value="${carrera.id}">
                        ${carrera.nombre}
                    </option>
                `;
            }

            if (carreraAlumno) {
                carreraAlumno.innerHTML += `
                    <option value="${carrera.id}">
                        ${carrera.nombre}
                    </option>
                `;
            }

            if (filtroCarreraMateria) {
                filtroCarreraMateria.innerHTML += `
                    <option value="${carrera.id}">
                        ${carrera.nombre}
                    </option>
                `;
            }
        });
    } catch (error) {
        console.error('Error al obtener las carreras: ', error);
    }
}


// CUATRIMESTRES

// GET ../api/api-cuatrimestres.php - obtener todos los cuatrimestres
async function getCuatrimestres() {
    try {
        const response = await fetch(`${URL_BASE}api-cuatrimestres.php`);
        const data = await response.json();

        const cuatrimestreAlumno = document.getElementById('cuatrimestreAlumno');
        const cuatrimestreParcial = document.getElementById('cuatrimestreParcial');
        const filtroCuatrimestreMateria = document.getElementById('filtroCuatrimestreMateria');

        if (cuatrimestreAlumno) {
            cuatrimestreAlumno.innerHTML = `
                <option value="">Selecciona un cuatrimestre</option>
            `;
        }

        if (cuatrimestreParcial) {
            cuatrimestreParcial.innerHTML = `
                <option value="">Sin cambio</option>
            `;
        }

        if (filtroCuatrimestreMateria) {
            filtroCuatrimestreMateria.innerHTML = `
                <option value="">Todos los cuatrimestres</option>
            `;
        }

        data.forEach(cuatrimestre => {
            if (cuatrimestreAlumno) {
                cuatrimestreAlumno.innerHTML += `
                    <option value="${cuatrimestre.id}">
                        ${cuatrimestre.nombre}
                    </option>
                `;
            }

            if (cuatrimestreParcial) {
                cuatrimestreParcial.innerHTML += `
                    <option value="${cuatrimestre.id}">
                        ${cuatrimestre.nombre}
                    </option>
                `;
            }

            if (filtroCuatrimestreMateria) {
                filtroCuatrimestreMateria.innerHTML += `
                    <option value="${cuatrimestre.id}">
                        ${cuatrimestre.nombre}
                    </option>
                `;
            }
        });
    } catch (error) {
        console.error('Error al obtener los cuatrimestres: ', error);
    }
}


// MATERIAS

// Función para mostrar las materias en la tabla
function mostrarMaterias(data) {
    const tbody = document.querySelector('#tabla-materias tbody');

    if (!tbody) {
        return;
    }

    tbody.innerHTML = '';

    if (data.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="sin-datos">
                    No se encontraron materias
                </td>
            </tr>
        `;
        return;
    }

    data.forEach(materia => {
        const tr = document.createElement('tr');

        tr.innerHTML = `
            <td>${materia.id}</td>
            <td>${materia.nombre}</td>
            <td>${materia.creditos}</td>
            <td>${materia.carrera}</td>
            <td>${materia.cuatrimestre}</td>
        `;

        tbody.appendChild(tr);
    });
}


// GET ../api/api-materias.php - obtener todas las materias
async function getMaterias() {
    const tbody = document.querySelector('#tabla-materias tbody');

    if (!tbody) {
        return;
    }

    try {
        const response = await fetch(`${URL_BASE}api-materias.php`);
        const data = await response.json();

        mostrarMaterias(data);
    } catch (error) {
        console.error('Error al obtener las materias: ', error);
    }
}


// GET ../api/api-materias.php?nombre=texto - buscar materias por nombre
async function buscarMaterias(nombre) {
    const tbody = document.querySelector('#tabla-materias tbody');

    if (!tbody) {
        return;
    }

    try {
        const response = await fetch(
            `${URL_BASE}api-materias.php?nombre=${encodeURIComponent(nombre)}`
        );

        const data = await response.json();

        mostrarMaterias(data);
    } catch (error) {
        console.error('Error al buscar las materias: ', error);
    }
}


// GET ../api/api-materias.php?carrera=1 - filtrar materias por carrera
async function filtrarMateriasPorCarrera(idCarrera) {
    const tbody = document.querySelector('#tabla-materias tbody');

    if (!tbody) {
        return;
    }

    try {
        const response = await fetch(
            `${URL_BASE}api-materias.php?carrera=${idCarrera}`
        );

        const data = await response.json();

        mostrarMaterias(data);
    } catch (error) {
        console.error('Error al filtrar las materias por carrera: ', error);
    }
}


// GET ../api/api-materias.php?cuatrimestre=1
async function filtrarMateriasPorCuatrimestre(idCuatrimestre) {
    const tbody = document.querySelector('#tabla-materias tbody');

    if (!tbody) {
        return;
    }

    try {
        const response = await fetch(
            `${URL_BASE}api-materias.php?cuatrimestre=${idCuatrimestre}`
        );

        const data = await response.json();

        mostrarMaterias(data);
    } catch (error) {
        console.error('Error al filtrar las materias por cuatrimestre: ', error);
    }
}


// GET ../api/api-materias.php - llenar select de materias
async function cargarMateriasSelect() {
    try {
        const response = await fetch(`${URL_BASE}api-materias.php`);
        const data = await response.json();

        const inscripcionMateria = document.getElementById('inscripcionMateria');
        const consultaMateria = document.getElementById('consultaMateria');

        if (inscripcionMateria) {
            inscripcionMateria.innerHTML = `
                <option value="">Selecciona una materia</option>
            `;
        }

        if (consultaMateria) {
            consultaMateria.innerHTML = `
                <option value="">Selecciona una materia</option>
            `;
        }

        data.forEach(materia => {
            if (inscripcionMateria) {
                inscripcionMateria.innerHTML += `
                    <option value="${materia.id}">
                        ${materia.nombre}
                    </option>
                `;
            }

            if (consultaMateria) {
                consultaMateria.innerHTML += `
                    <option value="${materia.id}">
                        ${materia.nombre}
                    </option>
                `;
            }
        });
    } catch (error) {
        console.error('Error al cargar las materias: ', error);
    }
}


// ALUMNOS

// Función para mostrar alumnos
function mostrarAlumnos(data) {
    const tbody = document.querySelector('#tabla-alumnos tbody');

    if (!tbody) {
        return;
    }

    tbody.innerHTML = '';

    if (data.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="sin-datos">
                    No se encontraron alumnos
                </td>
            </tr>
        `;
        return;
    }

    data.forEach(alumno => {
        let claseEstado = 'estado-activo';

        if (alumno.estatus === 'Baja') {
            claseEstado = 'estado-baja';
        }

        if (alumno.estatus === 'Egresado') {
            claseEstado = 'estado-egresado';
        }

        const tr = document.createElement('tr');

        tr.innerHTML = `
            <td>${alumno.id}</td>
            <td>${alumno.matricula}</td>
            <td>
                ${alumno.nombre}
                ${alumno.apellido_paterno}
                ${alumno.apellido_materno || ''}
            </td>
            <td>${alumno.correo}</td>
            <td>${alumno.carrera}</td>
            <td>${alumno.cuatrimestre}</td>
            <td>
                <span class="estado ${claseEstado}">
                    ${alumno.estatus}
                </span>
            </td>
            <td>
                <button
                    class="btn btn-amarillo btn-pequeno"
                    onclick="redirigirEditarAlumno(${alumno.id})">
                    Editar
                </button>

                <button
                    class="btn btn-verde btn-pequeno"
                    onclick="redirigirActualizarAlumno(${alumno.id})">
                    Estatus
                </button>

                <button
                    class="btn btn-gris btn-pequeno"
                    onclick="verMateriasAlumno(${alumno.id})">
                    Materias
                </button>

                <button
                    class="btn btn-rojo btn-pequeno"
                    onclick="eliminarAlumno(${alumno.id})">
                    Eliminar
                </button>
            </td>
        `;

        tbody.appendChild(tr);
    });
}


// GET ../api/api-alumnos.php - obtener todos los alumnos
async function getAlumnos() {
    const tbody = document.querySelector('#tabla-alumnos tbody');

    if (!tbody) {
        return;
    }

    try {
        const response = await fetch(`${URL_BASE}api-alumnos.php`);
        const data = await response.json();

        mostrarAlumnos(data);
    } catch (error) {
        console.error('Error al obtener los alumnos: ', error);
    }
}


// GET ../api/api-alumnos.php?nombre=texto
async function buscarAlumnosPorNombre(nombre) {
    const tbody = document.querySelector('#tabla-alumnos tbody');

    if (!tbody) {
        return;
    }

    try {
        const response = await fetch(
            `${URL_BASE}api-alumnos.php?nombre=${encodeURIComponent(nombre)}`
        );

        const data = await response.json();

        mostrarAlumnos(data);
    } catch (error) {
        console.error('Error al buscar los alumnos por nombre: ', error);
    }
}


// GET ../api/api-alumnos.php?matricula=texto
async function buscarAlumnosPorMatricula(matricula) {
    const tbody = document.querySelector('#tabla-alumnos tbody');

    if (!tbody) {
        return;
    }

    try {
        const response = await fetch(
            `${URL_BASE}api-alumnos.php?matricula=${encodeURIComponent(matricula)}`
        );

        const data = await response.json();

        mostrarAlumnos(data);
    } catch (error) {
        console.error('Error al buscar los alumnos por matrícula: ', error);
    }
}


// GET ../api/api-alumnos.php?carrera=1
async function filtrarAlumnosPorCarrera(idCarrera) {
    const tbody = document.querySelector('#tabla-alumnos tbody');

    if (!tbody) {
        return;
    }

    try {
        const response = await fetch(
            `${URL_BASE}api-alumnos.php?carrera=${idCarrera}`
        );

        const data = await response.json();

        mostrarAlumnos(data);
    } catch (error) {
        console.error('Error al filtrar los alumnos por carrera: ', error);
    }
}


// GET ../api/api-alumnos.php?id=1
async function getAlumnoPorId(id) {
    try {
        const response = await fetch(
            `${URL_BASE}api-alumnos.php?id=${id}`
        );

        if (response.ok) {
            const alumno = await response.json();
            return alumno;
        } else {
            console.log(
                'Error al obtener el alumno: ',
                response.statusText
            );
        }
    } catch (error) {
        console.error('Error al obtener el alumno: ', error);
    }
}


// GET ../api/api-alumnos.php - llenar select de alumnos
async function cargarAlumnosSelect() {
    try {
        const response = await fetch(`${URL_BASE}api-alumnos.php`);
        const data = await response.json();

        const inscripcionAlumno = document.getElementById('inscripcionAlumno');
        const consultaAlumno = document.getElementById('consultaAlumno');

        if (inscripcionAlumno) {
            inscripcionAlumno.innerHTML = `
                <option value="">Selecciona un alumno</option>
            `;
        }

        if (consultaAlumno) {
            consultaAlumno.innerHTML = `
                <option value="">Selecciona un alumno</option>
            `;
        }

        data.forEach(alumno => {
            const nombreCompleto = `
                ${alumno.nombre}
                ${alumno.apellido_paterno}
                ${alumno.apellido_materno || ''}
            `;

            if (inscripcionAlumno) {
                inscripcionAlumno.innerHTML += `
                    <option value="${alumno.id}">
                        ${alumno.matricula} - ${nombreCompleto}
                    </option>
                `;
            }

            if (consultaAlumno) {
                consultaAlumno.innerHTML += `
                    <option value="${alumno.id}">
                        ${alumno.matricula} - ${nombreCompleto}
                    </option>
                `;
            }
        });
    } catch (error) {
        console.error('Error al cargar los alumnos: ', error);
    }
}


// POST ../api/api-alumnos.php - registrar alumno
async function crearAlumno(
    matricula,
    nombre,
    apellidoPaterno,
    apellidoMaterno,
    correo,
    telefono,
    fechaNacimiento,
    idCarrera,
    cuatrimestreActual,
    estatus
) {
    try {
        const nuevoAlumno = {
            matricula: matricula,
            nombre: nombre,
            apellido_paterno: apellidoPaterno,
            apellido_materno: apellidoMaterno,
            correo: correo,
            telefono: telefono,
            fecha_nacimiento: fechaNacimiento,
            id_carrera: idCarrera,
            cuatrimestre_actual: cuatrimestreActual,
            estatus: estatus
        };

        const response = await fetch(
            `${URL_BASE}api-alumnos.php`,
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(nuevoAlumno)
            }
        );

        if (response.ok) {
            window.location.replace('index.html');
            return;
        } else {
            const errorData = await response.json();
            const mensaje =
                errorData.mensaje ||
                response.statusText ||
                'Error al registrar el alumno';

            mostrarMensaje(mensaje, 'error');
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al registrar el alumno: ', error);
        mostrarMensaje('No se pudo conectar con la API', 'error');
    }
}


// PUT ../api/api-alumnos.php?id=1
async function actualizarAlumno(
    id,
    matricula,
    nombre,
    apellidoPaterno,
    apellidoMaterno,
    correo,
    telefono,
    fechaNacimiento,
    idCarrera,
    cuatrimestreActual,
    estatus
) {
    try {
        const alumnoActualizado = {
            matricula: matricula,
            nombre: nombre,
            apellido_paterno: apellidoPaterno,
            apellido_materno: apellidoMaterno,
            correo: correo,
            telefono: telefono,
            fecha_nacimiento: fechaNacimiento,
            id_carrera: idCarrera,
            cuatrimestre_actual: cuatrimestreActual,
            estatus: estatus
        };

        const response = await fetch(
            `${URL_BASE}api-alumnos.php?id=${id}`,
            {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(alumnoActualizado)
            }
        );

        if (response.ok) {
            window.location.replace('index.html');
            return;
        } else {
            const errorData = await response.json();
            const mensaje =
                errorData.mensaje ||
                response.statusText ||
                'Error al actualizar el alumno';

            mostrarMensaje(mensaje, 'error');
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al actualizar el alumno: ', error);
        mostrarMensaje('No se pudo conectar con la API', 'error');
    }
}


// PATCH ../api/api-alumnos.php?id=1
async function actualizarAlumnoParcial(
    id,
    estatus,
    cuatrimestreActual
) {
    try {
        const alumnoActualizado = {
            estatus: estatus,
            cuatrimestre_actual: cuatrimestreActual
        };

        const response = await fetch(
            `${URL_BASE}api-alumnos.php?id=${id}`,
            {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(alumnoActualizado)
            }
        );

        if (response.ok) {
            window.location.replace('index.html');
            return;
        } else {
            const errorData = await response.json();
            const mensaje =
                errorData.mensaje ||
                response.statusText ||
                'Error al actualizar el alumno';

            mostrarMensaje(mensaje, 'error');
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al actualizar el alumno: ', error);
        mostrarMensaje('No se pudo conectar con la API', 'error');
    }
}


// DELETE ../api/api-alumnos.php?id=1
async function eliminarAlumno(id) {
    const confirmar = confirm('¿Deseas eliminar este alumno?');

    if (!confirmar) {
        return;
    }

    try {
        const response = await fetch(
            `${URL_BASE}api-alumnos.php?id=${id}`,
            {
                method: 'DELETE'
            }
        );

        if (response.ok) {
            const data = await response.json();

            mostrarMensaje(data.mensaje, 'exito');
            getAlumnos();
            return;
        } else {
            const errorData = await response.json();
            const mensaje =
                errorData.mensaje ||
                response.statusText ||
                'Error al eliminar el alumno';

            mostrarMensaje(mensaje, 'error');
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al eliminar el alumno: ', error);
        mostrarMensaje('No se pudo conectar con la API', 'error');
    }
}


// FUNCIONES DE LOS FORMULARIOS DE ALUMNOS

async function eventoCrearAlumno() {
    const matricula = document.getElementById('matricula').value.trim();
    const nombre = document.getElementById('nombre').value.trim();
    const apellidoPaterno = document.getElementById('apellidoPaterno').value.trim();
    const apellidoMaterno = document.getElementById('apellidoMaterno').value.trim();
    const correo = document.getElementById('correo').value.trim();
    const telefono = document.getElementById('telefono').value.trim();
    const fechaNacimiento = document.getElementById('fechaNacimiento').value;
    const idCarrera = document.getElementById('carreraAlumno').value;
    const cuatrimestreActual = document.getElementById('cuatrimestreAlumno').value;
    const estatus = document.getElementById('estatusAlumno').value;

    if (
        !matricula ||
        !nombre ||
        !apellidoPaterno ||
        !correo ||
        !idCarrera ||
        !cuatrimestreActual ||
        !estatus
    ) {
        mostrarMensaje('Complete los campos obligatorios', 'error');
        return;
    }

    await crearAlumno(
        matricula,
        nombre,
        apellidoPaterno,
        apellidoMaterno,
        correo,
        telefono,
        fechaNacimiento,
        idCarrera,
        cuatrimestreActual,
        estatus
    );
}


async function poblarFormularioEdicion(id) {
    const alumno = await getAlumnoPorId(id);

    if (alumno) {
        document.getElementById('idAlumno').value = alumno.id;
        document.getElementById('matricula').value = alumno.matricula;
        document.getElementById('nombre').value = alumno.nombre;
        document.getElementById('apellidoPaterno').value = alumno.apellido_paterno;
        document.getElementById('apellidoMaterno').value =
            alumno.apellido_materno || '';
        document.getElementById('correo').value = alumno.correo;
        document.getElementById('telefono').value =
            alumno.telefono || '';
        document.getElementById('fechaNacimiento').value =
            alumno.fecha_nacimiento || '';
        document.getElementById('carreraAlumno').value =
            alumno.id_carrera;
        document.getElementById('cuatrimestreAlumno').value =
            alumno.cuatrimestre_actual;
        document.getElementById('estatusAlumno').value =
            alumno.estatus;
    } else {
        mostrarMensaje('No se encontró el alumno', 'error');
    }
}


async function eventoActualizarAlumno() {
    const id = document.getElementById('idAlumno').value;
    const matricula = document.getElementById('matricula').value.trim();
    const nombre = document.getElementById('nombre').value.trim();
    const apellidoPaterno = document.getElementById('apellidoPaterno').value.trim();
    const apellidoMaterno = document.getElementById('apellidoMaterno').value.trim();
    const correo = document.getElementById('correo').value.trim();
    const telefono = document.getElementById('telefono').value.trim();
    const fechaNacimiento = document.getElementById('fechaNacimiento').value;
    const idCarrera = document.getElementById('carreraAlumno').value;
    const cuatrimestreActual = document.getElementById('cuatrimestreAlumno').value;
    const estatus = document.getElementById('estatusAlumno').value;

    if (
        !id ||
        !matricula ||
        !nombre ||
        !apellidoPaterno ||
        !correo ||
        !idCarrera ||
        !cuatrimestreActual ||
        !estatus
    ) {
        mostrarMensaje('Complete los campos obligatorios', 'error');
        return;
    }

    await actualizarAlumno(
        id,
        matricula,
        nombre,
        apellidoPaterno,
        apellidoMaterno,
        correo,
        telefono,
        fechaNacimiento,
        idCarrera,
        cuatrimestreActual,
        estatus
    );
}


async function poblarFormularioParcial(id) {
    const alumno = await getAlumnoPorId(id);

    if (alumno) {
        document.getElementById('idAlumnoParcial').value =
            alumno.id;

        document.getElementById('alumnoParcial').value =
            `${alumno.matricula} - ${alumno.nombre} ${alumno.apellido_paterno}`;
    } else {
        mostrarMensaje('No se encontró el alumno', 'error');
    }
}


async function eventoActualizarAlumnoParcial() {
    const id = document.getElementById('idAlumnoParcial').value;
    const estatus = document.getElementById('estatusParcial').value;
    const cuatrimestreActual =
        document.getElementById('cuatrimestreParcial').value;

    if (!estatus && !cuatrimestreActual) {
        mostrarMensaje(
            'Seleccione el estatus o el cuatrimestre',
            'error'
        );
        return;
    }

    await actualizarAlumnoParcial(
        id,
        estatus,
        cuatrimestreActual
    );
}


function redirigirEditarAlumno(id) {
    window.location.href = `editar-alumno.html?id=${id}`;
}


function redirigirActualizarAlumno(id) {
    window.location.href = `actualizar-alumno.html?id=${id}`;
}


function verMateriasAlumno(id) {
    window.location.href = `inscripciones.html?alumno=${id}`;
}


// Función para obtener parámetros de la URL
function obtenerParametro(nombreParametro) {
    const urlParams = new URLSearchParams(window.location.search);
    const valor = urlParams.get(nombreParametro);

    if (valor) {
        return valor;
    } else {
        return null;
    }
}


// INSCRIPCIONES

// POST ../api/api-inscripciones.php
async function crearInscripcion(
    idAlumno,
    idMateria,
    fechaInscripcion,
    periodo,
    calificacion
) {
    try {
        const nuevaInscripcion = {
            id_alumno: idAlumno,
            id_materia: idMateria,
            fecha_inscripcion: fechaInscripcion,
            periodo: periodo,
            calificacion: calificacion
        };

        const response = await fetch(
            `${URL_BASE}api-inscripciones.php`,
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(nuevaInscripcion)
            }
        );

        if (response.ok) {
            const data = await response.json();

            mostrarMensaje(data.mensaje, 'exito');

            document
                .getElementById('inscripcion-create-form')
                .reset();

            return;
        } else {
            const errorData = await response.json();
            const mensaje =
                errorData.mensaje ||
                response.statusText ||
                'Error al registrar la inscripción';

            mostrarMensaje(mensaje, 'error');
            console.log(mensaje);
        }
    } catch (error) {
        console.error(
            'Error al registrar la inscripción: ',
            error
        );

        mostrarMensaje(
            'No se pudo conectar con la API',
            'error'
        );
    }
}


// GET ../api/api-inscripciones.php?alumno=1
async function getInscripcionesPorAlumno(idAlumno) {
    const tbody = document.querySelector(
        '#tabla-inscripciones-alumno tbody'
    );

    if (!tbody) {
        return;
    }

    try {
        const response = await fetch(
            `${URL_BASE}api-inscripciones.php?alumno=${idAlumno}`
        );

        const data = await response.json();

        tbody.innerHTML = '';

        if (data.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="sin-datos">
                        El alumno no tiene materias inscritas
                    </td>
                </tr>
            `;
            return;
        }

        data.forEach(inscripcion => {
            let calificacion = 'Sin calificación';
            let periodo = '';

            if (inscripcion.calificacion !== null) {
                calificacion = inscripcion.calificacion;
            }

            if (inscripcion.periodo !== null) {
                periodo = inscripcion.periodo;
            }

            const tr = document.createElement('tr');

            tr.innerHTML = `
                <td>${inscripcion.materia}</td>
                <td>${inscripcion.fecha_inscripcion}</td>
                <td>${periodo}</td>
                <td>${calificacion}</td>
                <td>
                    <button
                        class="btn btn-rojo btn-pequeno"
                        onclick="eliminarInscripcion(${inscripcion.id})">
                        Eliminar
                    </button>
                </td>
            `;

            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error(
            'Error al consultar las materias del alumno: ',
            error
        );
    }
}


// GET ../api/api-inscripciones.php?materia=1
async function getAlumnosPorMateria(idMateria) {
    const tbody = document.querySelector(
        '#tabla-alumnos-materia tbody'
    );

    if (!tbody) {
        return;
    }

    try {
        const response = await fetch(
            `${URL_BASE}api-inscripciones.php?materia=${idMateria}`
        );

        const data = await response.json();

        tbody.innerHTML = '';

        if (data.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="sin-datos">
                        No hay alumnos inscritos en esta materia
                    </td>
                </tr>
            `;
            return;
        }

        data.forEach(inscripcion => {
            let calificacion = 'Sin calificación';
            let periodo = '';

            if (inscripcion.calificacion !== null) {
                calificacion = inscripcion.calificacion;
            }

            if (inscripcion.periodo !== null) {
                periodo = inscripcion.periodo;
            }

            const tr = document.createElement('tr');

            tr.innerHTML = `
                <td>${inscripcion.matricula}</td>
                <td>
                    ${inscripcion.nombre}
                    ${inscripcion.apellido_paterno}
                    ${inscripcion.apellido_materno || ''}
                </td>
                <td>${inscripcion.correo}</td>
                <td>${inscripcion.fecha_inscripcion}</td>
                <td>${periodo}</td>
                <td>${calificacion}</td>
            `;

            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error(
            'Error al consultar los alumnos de la materia: ',
            error
        );
    }
}


// DELETE ../api/api-inscripciones.php?id=1
async function eliminarInscripcion(id) {
    const confirmar = confirm(
        '¿Deseas eliminar esta inscripción?'
    );

    if (!confirmar) {
        return;
    }

    try {
        const response = await fetch(
            `${URL_BASE}api-inscripciones.php?id=${id}`,
            {
                method: 'DELETE'
            }
        );

        if (response.ok) {
            const data = await response.json();

            mostrarMensaje(data.mensaje, 'exito');

            const consultaAlumno =
                document.getElementById('consultaAlumno');

            if (consultaAlumno && consultaAlumno.value) {
                getInscripcionesPorAlumno(
                    consultaAlumno.value
                );
            }

            return;
        } else {
            const errorData = await response.json();
            const mensaje =
                errorData.mensaje ||
                response.statusText ||
                'Error al eliminar la inscripción';

            mostrarMensaje(mensaje, 'error');
            console.log(mensaje);
        }
    } catch (error) {
        console.error(
            'Error al eliminar la inscripción: ',
            error
        );

        mostrarMensaje(
            'No se pudo conectar con la API',
            'error'
        );
    }
}


async function eventoCrearInscripcion() {
    const idAlumno =
        document.getElementById('inscripcionAlumno').value;

    const idMateria =
        document.getElementById('inscripcionMateria').value;

    const fechaInscripcion =
        document.getElementById('fechaInscripcion').value;

    const periodo =
        document.getElementById('periodo').value.trim();

    const calificacion =
        document.getElementById('calificacion').value;

    if (!idAlumno || !idMateria || !fechaInscripcion) {
        mostrarMensaje(
            'El alumno, la materia y la fecha son obligatorios',
            'error'
        );
        return;
    }

    await crearInscripcion(
        idAlumno,
        idMateria,
        fechaInscripcion,
        periodo,
        calificacion
    );
}


// LLAMADAS DE FUNCIONES Y EVENTOS

document.addEventListener('DOMContentLoaded', async () => {

    // Cargar carreras
    if (
        document.getElementById('filtroCarreraAlumno') ||
        document.getElementById('carreraAlumno') ||
        document.getElementById('filtroCarreraMateria')
    ) {
        await getCarreras();
    }

    // Cargar cuatrimestres
    if (
        document.getElementById('cuatrimestreAlumno') ||
        document.getElementById('cuatrimestreParcial') ||
        document.getElementById('filtroCuatrimestreMateria')
    ) {
        await getCuatrimestres();
    }


    // PÁGINA DE ALUMNOS

    if (document.getElementById('tabla-alumnos')) {
        getAlumnos();
    }

    const buscarNombre =
        document.getElementById('buscarNombre');

    const buscarMatricula =
        document.getElementById('buscarMatricula');

    const filtroCarreraAlumno =
        document.getElementById('filtroCarreraAlumno');

    const btnLimpiarAlumnos =
        document.getElementById('btnLimpiarAlumnos');


    if (buscarNombre) {
        buscarNombre.addEventListener('input', () => {
            const nombre = buscarNombre.value.trim();

            if (buscarMatricula) {
                buscarMatricula.value = '';
            }

            if (filtroCarreraAlumno) {
                filtroCarreraAlumno.value = '';
            }

            if (nombre === '') {
                getAlumnos();
            } else {
                buscarAlumnosPorNombre(nombre);
            }
        });
    }


    if (buscarMatricula) {
        buscarMatricula.addEventListener('input', () => {
            const matricula =
                buscarMatricula.value.trim();

            if (buscarNombre) {
                buscarNombre.value = '';
            }

            if (filtroCarreraAlumno) {
                filtroCarreraAlumno.value = '';
            }

            if (matricula === '') {
                getAlumnos();
            } else {
                buscarAlumnosPorMatricula(matricula);
            }
        });
    }


    if (filtroCarreraAlumno) {
        filtroCarreraAlumno.addEventListener(
            'change',
            () => {
                const idCarrera =
                    filtroCarreraAlumno.value;

                if (buscarNombre) {
                    buscarNombre.value = '';
                }

                if (buscarMatricula) {
                    buscarMatricula.value = '';
                }

                if (idCarrera === '') {
                    getAlumnos();
                } else {
                    filtrarAlumnosPorCarrera(idCarrera);
                }
            }
        );
    }


    if (btnLimpiarAlumnos) {
        btnLimpiarAlumnos.addEventListener(
            'click',
            () => {
                buscarNombre.value = '';
                buscarMatricula.value = '';
                filtroCarreraAlumno.value = '';

                getAlumnos();
            }
        );
    }


    // FORMULARIO CREAR ALUMNO

    const alumnoCreateForm =
        document.getElementById('alumno-create-form');

    if (alumnoCreateForm) {
        alumnoCreateForm.addEventListener(
            'submit',
            event => {
                event.preventDefault();
                eventoCrearAlumno();
            }
        );
    }


    // FORMULARIO EDITAR ALUMNO

    const alumnoEditForm =
        document.getElementById('alumno-edit-form');

    if (alumnoEditForm) {
        const id = obtenerParametro('id');

        if (id) {
            await poblarFormularioEdicion(id);
        } else {
            mostrarMensaje(
                'No se proporcionó un ID de alumno',
                'error'
            );
        }

        alumnoEditForm.addEventListener(
            'submit',
            event => {
                event.preventDefault();
                eventoActualizarAlumno();
            }
        );
    }


    // FORMULARIO PATCH

    const alumnoPatchForm =
        document.getElementById('alumno-patch-form');

    if (alumnoPatchForm) {
        const id = obtenerParametro('id');

        if (id) {
            await poblarFormularioParcial(id);
        } else {
            mostrarMensaje(
                'No se proporcionó un ID de alumno',
                'error'
            );
        }

        alumnoPatchForm.addEventListener(
            'submit',
            event => {
                event.preventDefault();
                eventoActualizarAlumnoParcial();
            }
        );
    }


    // PÁGINA DE MATERIAS

    if (document.getElementById('tabla-materias')) {
        getMaterias();
    }

    const buscarMateria =
        document.getElementById('buscarMateria');

    const filtroCarreraMateria =
        document.getElementById('filtroCarreraMateria');

    const filtroCuatrimestreMateria =
        document.getElementById('filtroCuatrimestreMateria');

    const btnLimpiarMaterias =
        document.getElementById('btnLimpiarMaterias');


    if (buscarMateria) {
        buscarMateria.addEventListener('input', () => {
            const nombre =
                buscarMateria.value.trim();

            filtroCarreraMateria.value = '';
            filtroCuatrimestreMateria.value = '';

            if (nombre === '') {
                getMaterias();
            } else {
                buscarMaterias(nombre);
            }
        });
    }


    if (filtroCarreraMateria) {
        filtroCarreraMateria.addEventListener(
            'change',
            () => {
                const idCarrera =
                    filtroCarreraMateria.value;

                buscarMateria.value = '';
                filtroCuatrimestreMateria.value = '';

                if (idCarrera === '') {
                    getMaterias();
                } else {
                    filtrarMateriasPorCarrera(
                        idCarrera
                    );
                }
            }
        );
    }


    if (filtroCuatrimestreMateria) {
        filtroCuatrimestreMateria.addEventListener(
            'change',
            () => {
                const idCuatrimestre =
                    filtroCuatrimestreMateria.value;

                buscarMateria.value = '';
                filtroCarreraMateria.value = '';

                if (idCuatrimestre === '') {
                    getMaterias();
                } else {
                    filtrarMateriasPorCuatrimestre(
                        idCuatrimestre
                    );
                }
            }
        );
    }


    if (btnLimpiarMaterias) {
        btnLimpiarMaterias.addEventListener(
            'click',
            () => {
                buscarMateria.value = '';
                filtroCarreraMateria.value = '';
                filtroCuatrimestreMateria.value = '';

                getMaterias();
            }
        );
    }


    // PÁGINA DE INSCRIPCIONES

    const inscripcionCreateForm =
        document.getElementById(
            'inscripcion-create-form'
        );

    if (inscripcionCreateForm) {
        await cargarAlumnosSelect();
        await cargarMateriasSelect();

        inscripcionCreateForm.addEventListener(
            'submit',
            event => {
                event.preventDefault();
                eventoCrearInscripcion();
            }
        );

        const idAlumnoUrl =
            obtenerParametro('alumno');

        if (idAlumnoUrl) {
            document.getElementById(
                'consultaAlumno'
            ).value = idAlumnoUrl;

            getInscripcionesPorAlumno(
                idAlumnoUrl
            );
        }
    }


    const btnConsultarMaterias =
        document.getElementById(
            'btnConsultarMaterias'
        );

    if (btnConsultarMaterias) {
        btnConsultarMaterias.addEventListener(
            'click',
            () => {
                const idAlumno =
                    document.getElementById(
                        'consultaAlumno'
                    ).value;

                if (idAlumno) {
                    getInscripcionesPorAlumno(
                        idAlumno
                    );
                } else {
                    mostrarMensaje(
                        'Seleccione un alumno',
                        'error'
                    );
                }
            }
        );
    }


    const btnConsultarAlumnos =
        document.getElementById(
            'btnConsultarAlumnos'
        );

    if (btnConsultarAlumnos) {
        btnConsultarAlumnos.addEventListener(
            'click',
            () => {
                const idMateria =
                    document.getElementById(
                        'consultaMateria'
                    ).value;

                if (idMateria) {
                    getAlumnosPorMateria(
                        idMateria
                    );
                } else {
                    mostrarMensaje(
                        'Seleccione una materia',
                        'error'
                    );
                }
            }
        );
    }
});
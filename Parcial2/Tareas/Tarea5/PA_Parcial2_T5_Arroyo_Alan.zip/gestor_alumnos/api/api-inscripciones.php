<?php
require_once('../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['alumno'])) {
            $id_alumno = intval($_GET['alumno']);
            $stmt = $conn->prepare("SELECT i.id, i.id_alumno, i.id_materia, m.nombre AS materia, m.creditos, c.nombre AS carrera, cu.nombre AS cuatrimestre, i.fecha_inscripcion, i.calificacion, i.periodo FROM inscripciones i INNER JOIN materias m ON i.id_materia = m.id INNER JOIN carreras c ON m.id_carrera = c.id INNER JOIN cuatrimestres cu ON m.id_cuatrimestre = cu.id WHERE i.id_alumno = ? ORDER BY i.id");
            $stmt->bind_param("i", $id_alumno);
        } elseif (isset($_GET['materia'])) {
            $id_materia = intval($_GET['materia']);
            $stmt = $conn->prepare("SELECT i.id, a.id AS id_alumno, a.matricula, a.nombre, a.apellido_paterno, a.apellido_materno, a.correo, i.fecha_inscripcion, i.calificacion, i.periodo FROM inscripciones i INNER JOIN alumnos a ON i.id_alumno = a.id WHERE i.id_materia = ? ORDER BY a.nombre");
            $stmt->bind_param("i", $id_materia);
        } else {
            $stmt = $conn->prepare("SELECT i.id, i.id_alumno, i.id_materia, a.nombre, a.apellido_paterno, a.apellido_materno, m.nombre AS materia, i.fecha_inscripcion, i.calificacion, i.periodo FROM inscripciones i INNER JOIN alumnos a ON i.id_alumno = a.id INNER JOIN materias m ON i.id_materia = m.id ORDER BY i.id");
        }

        $stmt->execute();
        $resultado = $stmt->get_result();
        $inscripciones = array();

        while ($row = $resultado->fetch_assoc()) {
            $inscripciones[] = $row;
        }

        http_response_code(200);
        echo json_encode($inscripciones, JSON_UNESCAPED_UNICODE);
        $stmt->close();
        $conn->close();
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $id_alumno = intval($data['id_alumno'] ?? 0);
        $id_materia = intval($data['id_materia'] ?? 0);
        $fecha_inscripcion = trim($data['fecha_inscripcion'] ?? "");
        $calificacion = trim($data['calificacion'] ?? "");
        $periodo = trim($data['periodo'] ?? "");

        if ($id_alumno > 0 && $id_materia > 0 && !empty($fecha_inscripcion)) {
            $stmt = $conn->prepare("SELECT id FROM inscripciones WHERE id_alumno = ? AND id_materia = ?");
            $stmt->bind_param("ii", $id_alumno, $id_materia);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(400);
                echo json_encode(array("mensaje" => "El alumno ya está inscrito en esta materia"), JSON_UNESCAPED_UNICODE);
                $stmt->close();
                $conn->close();
                exit;
            }
            $stmt->close();

            $stmt = $conn->prepare("INSERT INTO inscripciones (id_alumno, id_materia, fecha_inscripcion, calificacion, periodo) VALUES (?, ?, ?, NULLIF(?, ''), NULLIF(?, ''))");
            $stmt->bind_param("iisss", $id_alumno, $id_materia, $fecha_inscripcion, $calificacion, $periodo);

            if ($stmt->execute()) {
                http_response_code(201);
                echo json_encode(array("mensaje" => "Inscripción registrada exitosamente"), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al registrar la inscripción: " . $stmt->error), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El alumno, la materia y la fecha son obligatorios"), JSON_UNESCAPED_UNICODE);
        }
        $conn->close();
        break;

    case 'DELETE':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("DELETE FROM inscripciones WHERE id = ?");
            $stmt->bind_param("i", $id);

            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("mensaje" => "Inscripción eliminada exitosamente"), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al eliminar la inscripción: " . $stmt->error), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para eliminar una inscripción"), JSON_UNESCAPED_UNICODE);
        }
        $conn->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Método no permitido"), JSON_UNESCAPED_UNICODE);
        $conn->close();
        break;
}

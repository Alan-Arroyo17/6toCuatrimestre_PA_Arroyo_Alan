<?php
require_once('../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre FROM carreras WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                $carrera = $resultado->fetch_assoc();
                http_response_code(200);
                echo json_encode($carrera, JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Carrera no encontrada"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        } else {
            $stmt = $conn->prepare("SELECT id, nombre FROM carreras ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $carreras = array();

            while ($row = $resultado->fetch_assoc()) {
                $carreras[] = $row;
            }

            http_response_code(200);
            echo json_encode($carreras, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Método no permitido"), JSON_UNESCAPED_UNICODE);
        $conn->close();
        break;
}

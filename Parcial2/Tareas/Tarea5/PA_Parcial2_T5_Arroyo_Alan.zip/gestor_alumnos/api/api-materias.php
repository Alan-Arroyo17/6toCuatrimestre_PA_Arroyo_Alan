<?php
require_once('../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $nombre_param = "%$nombre%";
            $stmt = $conn->prepare("SELECT m.id, m.nombre, m.creditos, m.id_carrera, c.nombre AS carrera, m.id_cuatrimestre, cu.nombre AS cuatrimestre FROM materias m INNER JOIN carreras c ON m.id_carrera = c.id INNER JOIN cuatrimestres cu ON m.id_cuatrimestre = cu.id WHERE m.nombre LIKE ? ORDER BY m.id");
            $stmt->bind_param("s", $nombre_param);
        } elseif (isset($_GET['carrera'])) {
            $id_carrera = intval($_GET['carrera']);
            $stmt = $conn->prepare("SELECT m.id, m.nombre, m.creditos, m.id_carrera, c.nombre AS carrera, m.id_cuatrimestre, cu.nombre AS cuatrimestre FROM materias m INNER JOIN carreras c ON m.id_carrera = c.id INNER JOIN cuatrimestres cu ON m.id_cuatrimestre = cu.id WHERE m.id_carrera = ? ORDER BY m.id");
            $stmt->bind_param("i", $id_carrera);
        } elseif (isset($_GET['cuatrimestre'])) {
            $id_cuatrimestre = intval($_GET['cuatrimestre']);
            $stmt = $conn->prepare("SELECT m.id, m.nombre, m.creditos, m.id_carrera, c.nombre AS carrera, m.id_cuatrimestre, cu.nombre AS cuatrimestre FROM materias m INNER JOIN carreras c ON m.id_carrera = c.id INNER JOIN cuatrimestres cu ON m.id_cuatrimestre = cu.id WHERE m.id_cuatrimestre = ? ORDER BY m.id");
            $stmt->bind_param("i", $id_cuatrimestre);
        } else {
            $stmt = $conn->prepare("SELECT m.id, m.nombre, m.creditos, m.id_carrera, c.nombre AS carrera, m.id_cuatrimestre, cu.nombre AS cuatrimestre FROM materias m INNER JOIN carreras c ON m.id_carrera = c.id INNER JOIN cuatrimestres cu ON m.id_cuatrimestre = cu.id ORDER BY m.id");
        }

        $stmt->execute();
        $resultado = $stmt->get_result();
        $materias = array();

        while ($row = $resultado->fetch_assoc()) {
            $materias[] = $row;
        }

        http_response_code(200);
        echo json_encode($materias, JSON_UNESCAPED_UNICODE);
        $stmt->close();
        $conn->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Método no permitido"), JSON_UNESCAPED_UNICODE);
        $conn->close();
        break;
}

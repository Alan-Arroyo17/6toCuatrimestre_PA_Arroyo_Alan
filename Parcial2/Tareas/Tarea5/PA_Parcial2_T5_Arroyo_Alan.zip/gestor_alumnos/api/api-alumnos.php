<?php
require_once('../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT a.id, a.matricula, a.nombre, a.apellido_paterno, a.apellido_materno, a.correo, a.telefono, a.fecha_nacimiento, a.id_carrera, c.nombre AS carrera, a.cuatrimestre_actual, cu.nombre AS cuatrimestre, a.estatus FROM alumnos a INNER JOIN carreras c ON a.id_carrera = c.id INNER JOIN cuatrimestres cu ON a.cuatrimestre_actual = cu.id WHERE a.id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                $alumno = $resultado->fetch_assoc();
                http_response_code(200);
                echo json_encode($alumno, JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Alumno no encontrado"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        } elseif (isset($_GET['matricula'])) {
            $matricula = trim($_GET['matricula']);
            $matricula_param = "%$matricula%";
            $stmt = $conn->prepare("SELECT a.id, a.matricula, a.nombre, a.apellido_paterno, a.apellido_materno, a.correo, a.telefono, a.fecha_nacimiento, a.id_carrera, c.nombre AS carrera, a.cuatrimestre_actual, cu.nombre AS cuatrimestre, a.estatus FROM alumnos a INNER JOIN carreras c ON a.id_carrera = c.id INNER JOIN cuatrimestres cu ON a.cuatrimestre_actual = cu.id WHERE a.matricula LIKE ? ORDER BY a.id");
            $stmt->bind_param("s", $matricula_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $alumnos = array();

            while ($row = $resultado->fetch_assoc()) {
                $alumnos[] = $row;
            }

            http_response_code(200);
            echo json_encode($alumnos, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        } elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $nombre_param = "%$nombre%";
            $stmt = $conn->prepare("SELECT a.id, a.matricula, a.nombre, a.apellido_paterno, a.apellido_materno, a.correo, a.telefono, a.fecha_nacimiento, a.id_carrera, c.nombre AS carrera, a.cuatrimestre_actual, cu.nombre AS cuatrimestre, a.estatus FROM alumnos a INNER JOIN carreras c ON a.id_carrera = c.id INNER JOIN cuatrimestres cu ON a.cuatrimestre_actual = cu.id WHERE a.nombre LIKE ? OR a.apellido_paterno LIKE ? OR a.apellido_materno LIKE ? ORDER BY a.id");
            $stmt->bind_param("sss", $nombre_param, $nombre_param, $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $alumnos = array();

            while ($row = $resultado->fetch_assoc()) {
                $alumnos[] = $row;
            }

            http_response_code(200);
            echo json_encode($alumnos, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        } elseif (isset($_GET['carrera'])) {
            $id_carrera = intval($_GET['carrera']);
            $stmt = $conn->prepare("SELECT a.id, a.matricula, a.nombre, a.apellido_paterno, a.apellido_materno, a.correo, a.telefono, a.fecha_nacimiento, a.id_carrera, c.nombre AS carrera, a.cuatrimestre_actual, cu.nombre AS cuatrimestre, a.estatus FROM alumnos a INNER JOIN carreras c ON a.id_carrera = c.id INNER JOIN cuatrimestres cu ON a.cuatrimestre_actual = cu.id WHERE a.id_carrera = ? ORDER BY a.id");
            $stmt->bind_param("i", $id_carrera);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $alumnos = array();

            while ($row = $resultado->fetch_assoc()) {
                $alumnos[] = $row;
            }

            http_response_code(200);
            echo json_encode($alumnos, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        } else {
            $stmt = $conn->prepare("SELECT a.id, a.matricula, a.nombre, a.apellido_paterno, a.apellido_materno, a.correo, a.telefono, a.fecha_nacimiento, a.id_carrera, c.nombre AS carrera, a.cuatrimestre_actual, cu.nombre AS cuatrimestre, a.estatus FROM alumnos a INNER JOIN carreras c ON a.id_carrera = c.id INNER JOIN cuatrimestres cu ON a.cuatrimestre_actual = cu.id ORDER BY a.id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $alumnos = array();

            while ($row = $resultado->fetch_assoc()) {
                $alumnos[] = $row;
            }

            http_response_code(200);
            echo json_encode($alumnos, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $matricula = trim($data['matricula'] ?? "");
        $nombre = trim($data['nombre'] ?? "");
        $apellido_paterno = trim($data['apellido_paterno'] ?? "");
        $apellido_materno = trim($data['apellido_materno'] ?? "");
        $correo = trim($data['correo'] ?? "");
        $telefono = trim($data['telefono'] ?? "");
        $fecha_nacimiento = trim($data['fecha_nacimiento'] ?? "");
        $id_carrera = intval($data['id_carrera'] ?? 0);
        $cuatrimestre_actual = intval($data['cuatrimestre_actual'] ?? 0);
        $estatus = trim($data['estatus'] ?? "");

        if (!empty($matricula) && !empty($nombre) && !empty($apellido_paterno) && !empty($correo) && $id_carrera > 0 && $cuatrimestre_actual > 0 && !empty($estatus)) {
            $stmt = $conn->prepare("INSERT INTO alumnos (matricula, nombre, apellido_paterno, apellido_materno, correo, telefono, fecha_nacimiento, id_carrera, cuatrimestre_actual, estatus) VALUES (?, ?, ?, NULLIF(?, ''), ?, NULLIF(?, ''), NULLIF(?, ''), ?, ?, ?)");
            $stmt->bind_param("sssssssiis", $matricula, $nombre, $apellido_paterno, $apellido_materno, $correo, $telefono, $fecha_nacimiento, $id_carrera, $cuatrimestre_actual, $estatus);

            if ($stmt->execute()) {
                http_response_code(201);
                echo json_encode(array("mensaje" => "Alumno registrado exitosamente"), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al registrar el alumno: " . $stmt->error), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Complete los campos obligatorios"), JSON_UNESCAPED_UNICODE);
        }
        $conn->close();
        break;

    case 'PUT':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);
            $matricula = trim($data['matricula'] ?? "");
            $nombre = trim($data['nombre'] ?? "");
            $apellido_paterno = trim($data['apellido_paterno'] ?? "");
            $apellido_materno = trim($data['apellido_materno'] ?? "");
            $correo = trim($data['correo'] ?? "");
            $telefono = trim($data['telefono'] ?? "");
            $fecha_nacimiento = trim($data['fecha_nacimiento'] ?? "");
            $id_carrera = intval($data['id_carrera'] ?? 0);
            $cuatrimestre_actual = intval($data['cuatrimestre_actual'] ?? 0);
            $estatus = trim($data['estatus'] ?? "");

            if (!empty($matricula) && !empty($nombre) && !empty($apellido_paterno) && !empty($correo) && $id_carrera > 0 && $cuatrimestre_actual > 0 && !empty($estatus)) {
                $stmt = $conn->prepare("UPDATE alumnos SET matricula = ?, nombre = ?, apellido_paterno = ?, apellido_materno = NULLIF(?, ''), correo = ?, telefono = NULLIF(?, ''), fecha_nacimiento = NULLIF(?, ''), id_carrera = ?, cuatrimestre_actual = ?, estatus = ? WHERE id = ?");
                $stmt->bind_param("sssssssiisi", $matricula, $nombre, $apellido_paterno, $apellido_materno, $correo, $telefono, $fecha_nacimiento, $id_carrera, $cuatrimestre_actual, $estatus, $id);

                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array("mensaje" => "Alumno actualizado exitosamente"), JSON_UNESCAPED_UNICODE);
                } else {
                    http_response_code(500);
                    echo json_encode(array("mensaje" => "Error al actualizar el alumno: " . $stmt->error), JSON_UNESCAPED_UNICODE);
                }
                $stmt->close();
            } else {
                http_response_code(400);
                echo json_encode(array("mensaje" => "Complete los campos obligatorios"), JSON_UNESCAPED_UNICODE);
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un alumno"), JSON_UNESCAPED_UNICODE);
        }
        $conn->close();
        break;

    case 'PATCH':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);
            $estatus = trim($data['estatus'] ?? "");
            $cuatrimestre_actual = trim($data['cuatrimestre_actual'] ?? "");

            if (!empty($estatus) || !empty($cuatrimestre_actual)) {
                $stmt = $conn->prepare("UPDATE alumnos SET estatus = COALESCE(NULLIF(?, ''), estatus), cuatrimestre_actual = COALESCE(NULLIF(?, ''), cuatrimestre_actual) WHERE id = ?");
                $stmt->bind_param("ssi", $estatus, $cuatrimestre_actual, $id);

                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array("mensaje" => "Alumno actualizado exitosamente"), JSON_UNESCAPED_UNICODE);
                } else {
                    http_response_code(500);
                    echo json_encode(array("mensaje" => "Error al actualizar el alumno: " . $stmt->error), JSON_UNESCAPED_UNICODE);
                }
                $stmt->close();
            } else {
                http_response_code(400);
                echo json_encode(array("mensaje" => "El estatus o el cuatrimestre es obligatorio"), JSON_UNESCAPED_UNICODE);
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un alumno"), JSON_UNESCAPED_UNICODE);
        }
        $conn->close();
        break;

    case 'DELETE':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);

            $stmt = $conn->prepare("DELETE FROM inscripciones WHERE id_alumno = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM alumnos WHERE id = ?");
            $stmt->bind_param("i", $id);

            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("mensaje" => "Alumno eliminado exitosamente"), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al eliminar el alumno: " . $stmt->error), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para eliminar un alumno"), JSON_UNESCAPED_UNICODE);
        }
        $conn->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Método no permitido"), JSON_UNESCAPED_UNICODE);
        $conn->close();
        break;
}

const URL_BASE = 'http://192.168.1.117/videojuegos_app/';

// GET ../api/api-videojuegos.php — listar todas
//Videojuegos
async function crearVideojuego() {
    const img = document.getElementById("imagen").files[0];
    try {
        let res;
        if (img) {
            const formData = new FormData();
            formData.append("titulo", document.getElementById("titulo").value);
            formData.append("descripcion", document.getElementById("descripcion").value);
            formData.append("precio", document.getElementById("precio").value);
            formData.append("lanzamiento", document.getElementById("lanzamiento").value);
            formData.append("calificacion", document.getElementById("calificacion").value);
            formData.append("id_genero", document.getElementById("genero-select").value);
            formData.append("id_plataforma", document.getElementById("plataforma-select").value);
            formData.append("imagen", img);

            res = await fetch(URL_BASE + "api-videojuego.php", {
                method: "POST",
                body: formData
            });
        } else {
            const datos = {
                titulo: document.getElementById("titulo").value,
                descripcion: document.getElementById("descripcion").value,
                precio: parseFloat(document.getElementById("precio").value),
                lanzamiento: document.getElementById("lanzamiento").value,
                calificacion: parseFloat(document.getElementById("calificacion").value),
                imagen: "",
                id_genero: parseInt(document.getElementById("genero-select").value),
                id_plataforma: parseInt(document.getElementById("plataforma-select").value)
            };

            res = await fetch(URL_BASE + "api-videojuego.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(datos)
            });
        }

        const data = await res.json();
        if (res.ok) {
            alert("Videojuego creado con éxito");
            window.location.href = "index.html";
        } else {
            alert(data.message || "Error al crear el videojuego");
        }

    } catch (error) {
        console.error(error);
        alert("Error de conexión");
    }
}

async function getVideojuegos() {
    const tbody = document.querySelector('#tabla-videojuegos tbody');
    if (!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-videojuego.php`);
        const data = await response.json();
        tbody.innerHTML = '';
        data.forEach(videojuego => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${videojuego.id}</td>
                <td>${videojuego.titulo}</td>
                <td>${videojuego.descripcion}</td>
                <td>${videojuego.precio}</td>
                <td>${videojuego.lanzamiento}</td>
                <td>${videojuego.calificacion}</td>
                <td><img src="${URL_BASE}api-imagen.php?nombre=${encodeURIComponent(videojuego.imagen)}" alt="${videojuego.titulo}" width="100"></td>
                <td>
                    <button class="btn btn-warning btn-sm" onclick="redirigirEditarVideojuego(${videojuego.id})">Editar</button>
                    <button class="btn btn-danger btn-sm" onclick="if(confirm('¿Estás seguro de que deseas eliminar este videojuego?')) { eliminarVideojuego(${videojuego.id}); }">Eliminar</button>
                    <button class="btn btn-info btn-sm" onclick="redirigirIDPatch(${videojuego.id})">Edición Rápida</button>
                </td>
            `;
            tbody.appendChild(tr);
        })
    } catch (error) {
        console.error('Error al obtener las videojuegos: ', error);
    }
}

async function getVideojuegoPorID(id) {
    try {
        const response = await fetch(`${URL_BASE}api-videojuego.php?id=${id}`);
        if (response.ok) {
            const videojuego = await response.json();
            return videojuego;
        } else {
            console.log('Error al obtener el videojuego: ', response.statusText);
        }
    } catch (error) {
        console.error('Error al obtener el videojuego: ', error);
    }
}

async function poblarFormularioEdicion(id) {
    const videojuego = await getVideojuegoPorID(id);
    if (videojuego) {
        document.getElementById('titulo').value = videojuego.titulo;
        document.getElementById('descripcion').value = videojuego.descripcion;
        document.getElementById('precio').value = videojuego.precio;
        document.getElementById('lanzamiento').value = videojuego.lanzamiento;
        document.getElementById('calificacion').value = videojuego.calificacion;
        document.getElementById('genero-select').value = videojuego.id_genero;
        document.getElementById('plataforma-select').value = videojuego.id_plataforma;

        const imagenActual = document.getElementById("preview-imagen");
        if (imagenActual && videojuego.imagen) {
            imagenActual.src = `${URL_BASE}api-imagen.php?nombre=${encodeURIComponent(videojuego.imagen)}`;
        }
    } else {
        console.log('No se pudo poblar el formulario de edición: videojuego no encontrado');
    }
}

async function buscarVideojuegos(nombre) {
    const tbody = document.querySelector('#tabla-videojuegos tbody');
    if (!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-videojuego.php?titulo=${encodeURIComponent(nombre)}`);
        const data = await response.json();
        tbody.innerHTML = '';
        data.forEach(videojuego => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${videojuego.id}</td>
                <td>${videojuego.titulo}</td>
                <td>${videojuego.descripcion}</td>
                <td>${videojuego.precio}</td>
                <td>${videojuego.lanzamiento}</td>
                <td>${videojuego.calificacion}</td>
                <td><img src="${URL_BASE}api-imagen.php?nombre=${encodeURIComponent(videojuego.imagen)}" alt="${videojuego.titulo}" width="100"></td>
                <td>
                    <button class="btn btn-warning btn-sm" onclick="redirigirEditarVideojuego(${videojuego.id})">Editar</button>
                    <button class="btn btn-danger btn-sm" onclick="if(confirm('¿Estás seguro de que deseas eliminar este videojuego?')) { eliminarVideojuego(${videojuego.id}); }">Eliminar</button>
                    <button class="btn btn-info btn-sm" onclick="edicionRapidaPatch(${videojuego.id})">Edición Rápida</button>
                </td>
            `;
            tbody.appendChild(tr);
        })
    } catch (error) {
        console.error('Error al buscar los videojuegos: ', error);
    }
}

async function eliminarVideojuego(id) {
    try {
        const response = await fetch(`${URL_BASE}api-videojuego.php?id=${id}`, {
            method: 'DELETE'
        });
        if (response.ok) {
            window.location.replace('index.html'); 
            return;
        } else {
            const errorData = await response.json().catch(() => null); 
            const mensaje = errorData?.mensaje || response.statusText || 'Error al eliminar el videojuego';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al eliminar el videojuego: ', error);
    }
}

async function cargarGeneros() {
    const select = document.getElementById("genero-select");
    try {
        const response = await fetch(`${URL_BASE}api-genero.php`);
        const generos = await response.json();

        generos.forEach(genero => {
            const option = document.createElement("option");
            option.value = genero.id;
            option.textContent = genero.nombre;
            select.appendChild(option);
        });

    } catch (error) {
        console.error(error);
    }
}

async function getVideojuegosPorGenero() {
    const tbody = document.querySelector('#tabla-videojuegos tbody');
    const select = document.getElementById("genero-select");
    const genero = select.options[select.selectedIndex].text;

    try {
        const response = await fetch(`${URL_BASE}api-videojuego.php?genero=${encodeURIComponent(genero)}`);
        const data = await response.json();
        tbody.innerHTML = "";
        data.forEach(videojuego => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td>${videojuego.id}</td>
                <td>${videojuego.titulo}</td>
                <td>${videojuego.descripcion}</td>
                <td>${videojuego.precio}</td>
                <td>${videojuego.lanzamiento}</td>
                <td>${videojuego.calificacion}</td>
                <td>
                    <img src="${URL_BASE}api-imagen.php?nombre=${encodeURIComponent(videojuego.imagen)}" width="100">
                </td>
                <td>
                    <button class="btn btn-warning btn-sm" onclick="redirigirEditarVideojuego(${videojuego.id})">Editar</button>
                    <button class="btn btn-danger btn-sm" onclick="if(confirm('¿Estás seguro de que deseas eliminar este videojuego?')) { eliminarVideojuego(${videojuego.id}); }">Eliminar</button>
                    <button class="btn btn-info btn-sm" onclick="edicionRapidaPatch(${videojuego.id})">Edición Rápida</button>
                </td>
            `;
            tbody.appendChild(tr);
        });

    } catch (error) {
        console.error('Error al obtener los videojuegos por género: ', error);
    }
}

async function cargarPlataformas() {
    const select = document.getElementById("plataforma-select");
    try {
        const response = await fetch(`${URL_BASE}api-plataforma.php`);
        const plataformas = await response.json();

        plataformas.forEach(plataforma => {
            const option = document.createElement("option");
            option.value = plataforma.id;
            option.textContent = plataforma.nombre;
            select.appendChild(option);
        });

    } catch (error) {
        console.error(error);
    }
}

async function getVideojuegosPorPlataforma() {
    const tbody = document.querySelector('#tabla-videojuegos tbody');
    const select = document.getElementById("plataforma-select");
    const plataforma = select.options[select.selectedIndex].text;
    try {

        const response = await fetch(`${URL_BASE}api-videojuego.php?plataforma=${encodeURIComponent(plataforma)}`);
        const data = await response.json();
        tbody.innerHTML = "";
        data.forEach(videojuego => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td>${videojuego.id}</td>
                <td>${videojuego.titulo}</td>
                <td>${videojuego.descripcion}</td>
                <td>${videojuego.precio}</td>
                <td>${videojuego.lanzamiento}</td>
                <td>${videojuego.calificacion}</td>
                <td>
                    <img src="${URL_BASE}api-imagen.php?nombre=${encodeURIComponent(videojuego.imagen)}" width="100">
                </td>
                <td>
                    <button class="btn btn-warning btn-sm" onclick="redirigirEditarVideojuego(${videojuego.id})">Editar</button>
                    <button class="btn btn-danger btn-sm" onclick="if(confirm('¿Estás seguro de que deseas eliminar este videojuego?')) { eliminarVideojuego(${videojuego.id}); }">Eliminar</button>
                    <button class="btn btn-info btn-sm" onclick="redirigirIDPatch(${videojuego.id})">Edición Rápida</button>
                </td>
            `;
            tbody.appendChild(tr);

        });

    } catch (error) {
        console.error(error);
    }
}

async function redirigirEditarVideojuego(id) {
    window.location.href = `editar.html?id=${id}`; 
}

async function redirigirIDPatch(id) {
    window.location.href = `edicionRapida.html?id=${id}`;
}

async function poblarFormularioEdicionRapida(id) {
    const videojuego = await getVideojuegoPorID(id);
    if (videojuego) {
        document.getElementById("precio").value = videojuego.precio;
        document.getElementById("calificacion").value = videojuego.calificacion;
    } else {
        console.log("No se pudo poblar el formulario de edición rápida");
    }
}

async function edicionRapidaPatch(id) {
    try {
        const datos = {
            precio: document.getElementById("precio").value,
            calificacion: document.getElementById("calificacion").value

        };
        const response = await fetch(`${URL_BASE}api-videojuego.php?id=${id}`, {
            method: "PATCH",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(datos)
        });
        if (response.ok) {
            alert("Videojuego actualizado con éxito");
            window.location.replace("index.html");
        } else {
            console.log("Error al actualizar");
        }
    } catch (error) {
        console.error(error);
    }
}

async function getGeneros(){
    const tbody = document.querySelector('#tabla-generos tbody');
    if (!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-genero.php`);
        const data = await response.json();
        tbody.innerHTML = '';
        data.forEach(genero => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${genero.id}</td>
                <td>${genero.nombre}</td>
            `;
            tbody.appendChild(tr);
        })
    } catch (error) {
        console.error('Error al obtener los generos: ', error);
    }
}


async function getPlataformas(){
    const tbody = document.querySelector("#tabla-plataformas tbody");
    if(!tbody){
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-plataforma.php`);
        const data = await response.json();
        tbody.innerHTML = '';
        data.forEach(plataforma =>{
            const tr = document.createElement('tr');
            tr.innerHTML=`
                <td>${plataforma.id}</td>
                <td>${plataforma.nombre}</td>
            `;
            tbody.appendChild(tr);
        })
    } catch (error) {
        console.error('Error al obtener las plataformas: ', error);
    }
}

async function actualizarVideojuego(id) {
    const img = document.getElementById("imagen").files[0];
    try {

        let response;

        if (img) {

            const formData = new FormData();

            formData.append("titulo", document.getElementById("titulo").value);
            formData.append("descripcion", document.getElementById("descripcion").value);
            formData.append("precio", document.getElementById("precio").value);
            formData.append("lanzamiento", document.getElementById("lanzamiento").value);
            formData.append("calificacion", document.getElementById("calificacion").value);
            formData.append("id_genero", document.getElementById("genero-select").value);
            formData.append("id_plataforma", document.getElementById("plataforma-select").value);
            formData.append("imagen", img);

            response = await fetch(`${URL_BASE}api-videojuego.php?id=${id}`, {
                method: 'PUT',
                body: formData
            });

        } else {

            const videojuegoActualizado = {
                titulo: document.getElementById("titulo").value,
                descripcion: document.getElementById("descripcion").value,
                precio: document.getElementById("precio").value,
                lanzamiento: document.getElementById("lanzamiento").value,
                calificacion: document.getElementById("calificacion").value,
                imagen: document.getElementById("preview-imagen").src.split("nombre=")[1] || "",
                id_genero: document.getElementById("genero-select").value,
                id_plataforma: document.getElementById("plataforma-select").value
            };

            response = await fetch(`${URL_BASE}api-videojuego.php?id=${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(videojuegoActualizado)
            });

        }

        if (response.ok) {
            alert("Videojuego actualizado con éxito");
            window.location.replace('index.html');
            return;
        } else {
            const errorData = await response.json().catch(() => null);
            const mensaje = errorData?.mensaje || response.statusText || 'Error al actualizar el videojuego';
            console.log(mensaje);
        }

    } catch (error) {
        console.error('Error al actualizar el videojuego: ', error);
    }
}

async function eventoCrearVideojuego() {
    const nombre = document.getElementById('titulo').value.trim(); 
    const descripcion = document.getElementById('descripcion').value.trim(); 
    const precio = document.getElementById('precio').value.trim();
    const lanzamiento = document.getElementById('lanzamiento').value.trim();
    const calificacion = document.getElementById('calificacion').value.trim();
    const id_genero = document.getElementById('genero-select').value;
    const id_plataforma = document.getElementById('plataforma-select').value;
    if (!nombre) {
        console.log('El titulo es obligatorio');
        return;
    }
    await crearVideojuego(nombre, descripcion, precio, lanzamiento, calificacion, id_genero, id_plataforma);
}

async function obtenerId() {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    if (id) {
        return id;
    } else {
        console.log('No se proporcionó un ID de videojuego para editar');
        return null;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    getVideojuegos();
    cargarGeneros();
    cargarPlataformas();
    getGeneros();
    getPlataformas();
  
    const videojuegoForm = document.getElementById('crear-videojuego');
    const videojuegoEditForm = document.getElementById('formEditar');
    const formularioPatch = document.getElementById("formEdicionRapida");
    if (videojuegoForm) {
        videojuegoForm.addEventListener('submit', (event) => {
            event.preventDefault(); 
            eventoCrearVideojuego();
        });
    }

    const generoSelect = document.getElementById("genero-select");
    if (generoSelect) {
        generoSelect.addEventListener("change", () => {
            if (generoSelect.value === "") {
                getVideojuegos();
            } else {
                getVideojuegosPorGenero(generoSelect.value);
            }
        });
    }

    const plataformaSelect = document.getElementById("plataforma-select");
    if (plataformaSelect) {
        plataformaSelect.addEventListener("change", () => {
            if (plataformaSelect.value === "") {
                getVideojuegos();
            } else {
                getVideojuegosPorPlataforma(plataformaSelect.value);
            }
        });
    }

    if (videojuegoEditForm) {
        obtenerId().then((id) => { 
            if (id) {
                poblarFormularioEdicion(id);
            } else {
                console.log('No se proporcionó un ID de videojuego para editar');
            }
        });
        videojuegoEditForm.addEventListener('submit', (event) => {
            event.preventDefault();
            obtenerId().then((id) => {
                if (id) {
                    actualizarVideojuego(id);
                } else {
                    console.log('No se proporcionó un ID de videojuego para actualizar');
                }
            });
        });
    }

    if (formularioPatch) {
        obtenerId().then((id) => {
            if (id) {
                poblarFormularioEdicionRapida(id);
            } else {
                console.log("No se proporcionó un ID");
            }
        });
        formularioPatch.addEventListener("submit", (event) => {
            event.preventDefault();
            obtenerId().then((id) => {
                if (id) {
                    edicionRapidaPatch(id);
                } else {
                    console.log("No se proporcionó un ID");
                }
            });
        });
    }    

    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            const nombre = searchInput.value.trim();
            if (nombre === '') {
                getVideojuegos();
            } else {
                buscarVideojuegos(nombre);
            }
        });
    }
});